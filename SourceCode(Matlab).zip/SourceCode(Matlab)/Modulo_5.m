%Modulo_5
WB = waitbar(32/77,'Computing Energy A Method');
%Metodo Energetico "A" (Mezzi)

fprintf (filereso,'%s \r\n','Computing Energy A Method');
%Trattamento curva metodo Mezzi
eM = WORK./massmez;
fM = shear(:,1)./massmez;
uyM(1,1) = 0;
uyM(2:nstep,1) = 2.*((u(2:nstep,1)-(eM(2:nstep,1)./fM(2:nstep,1))));
duttM(1,1) = 1;
duttM(2:nstep,1) = u(2:nstep,1)./uyM(2:nstep,1);
kM(2:nstep,1) = shear(2:nstep,1)./uyM(2:nstep,1);
kM(1,1) = kM(2,1);
TM = 2*pi*sqrt(massmez./kM);
TM(1,1) = TM(2,1); 
WB = waitbar(33/77);

SWB = waitbar(0,'Energy "A" Method: Processing Status');
SWB = waitbar(1/(2*nstep(1,1)));
fprintf (filereso,'%s \r\n','Computing Intersection Curve-Spectra');
%Determinazione delle intersezioni della curva per con i vari spettri
SolS = [ ];
for k=1:ndutt
    stop = 0;
    for i=2:nstep
        SWB = waitbar(((k-1)*nstep(1,1)+i)/((ndutt+1)*nstep(1,1)));
        for j=2:nspec
        if stop==0;
        X1 = u(i-1);
        X2 = u(i);
        Y1 = eM(i-1);
        Y2 = eM(i);
        Xa = Sd(j-1,k);
        Xb = Sd(j,k);
        Ya = Se(j-1,k);
        Yb = Se(j,k);
        if (X2-X1)~=0
            alfa = (Y2-Y1)/(X2-X1);
            beta = -1;
            teta = alfa*X1-Y1; 
        else
            alfa = 1;
            beta = 0;
            teta = X1;    
        end
        if (Xb-Xa)~=0
            epsilon = (Yb-Ya)/(Xb-Xa);
            delta = -1;
            fi = epsilon*Xa-Ya;
        else
            epsilon = 1;
            delta = 0;
            fi = Y1;
        end        
        A = [alfa beta;epsilon delta];
        B = [teta;fi];
        if det(A)~=0
            S = inv(A)*B;
            Sx = S(1,1);
            Sy = S(2,1);
            if abs(X2-X1)>=abs(Sx-X1) &...
               abs(Xb-Xa)>=abs(Sx-Xa) &...
               abs(Y2-Y1)>=abs(Sy-Y1) &...
               abs(Yb-Ya)>=abs(Sy-Ya)    
               SolS = [SolS;duttility(k),Sx,Sy];
               stop=1; 
            end
        end
    
    end
end
end
end
WB = waitbar(34/77);

fprintf (filereso,'%s \r\n','Computing Intersection Curve-Ductulity');
%Determinazione della soluzione nel piano spostemento - duttilit�
stop = 0;
SolM = [];
for i=2:nstep
    SWB = waitbar(((nstep(1,1)*ndutt)+i)/((ndutt+1)*nstep(1,1)));
    con = size(SolS);    
    for j=2:max(con(1,1))
        if stop==0;
        X1 = u(i-1);
        X2 = u(i);
        Y1 = duttM(i-1);
        Y2 = duttM(i);
        Xa = SolS(j-1,2);
        Xb = SolS(j,2);
        Ya = SolS(j-1,1);
        Yb = SolS(j,1);
        if (X2-X1)~=0
            alfa = (Y2-Y1)/(X2-X1);
            beta = -1;
            teta = alfa*X1-Y1; 
        else
            alfa = 1;
            beta = 0;
            teta = X1;    
        end
        if (Xb-Xa)~=0
            epsilon = (Yb-Ya)/(Xb-Xa);
            delta = -1;
            fi = epsilon*Xa-Ya;
        else
            epsilon = 1;
            delta = 0;
            fi = Y1;
        end        
        A = [alfa beta;epsilon delta];
        B = [teta;fi];
        if det(A)~=0
            S = inv(A)*B;
            Sx = S(1,1);
            Sy = S(2,1);
            if abs(X2-X1)>=abs(Sx-X1) &...
               abs(Xb-Xa)>=abs(Sx-Xa) &...
               abs(Y2-Y1)>=abs(Sy-Y1) &...
               abs(Yb-Ya)>=abs(Sy-Ya)    
               SolM = [Sx,Sy];
               nsolM = i;
               stop=1; 
            end
        end
    
    end
end
end
WB = waitbar(35/77);
close(SWB);

%CONTROLLO DELLA MANCATA INTERSEZIONE --> NO SOLUZIONE !!!!!
%Se non trova intersezioni tra curva spettrale e curva pushover in termini
%di duttilit� spostamento allora assegna per default nulla la soluzione e
%prende la deformata al primo passo come soluzione
size(SolM);
if ans(1,1) == 0
    disp ('Soluzione non trovata');
    SolM = [0,0];
    nsolM = 2; %� 2 altrimenti ci sono coordinate nsolM-1 = 0 e da problemi
end

%Grafico spostamento - energia
fprintf (filereso,'%s \r\n','Saving Fig.4.1_Energy_Method_A1');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Plotta gli spettri
for i = 1:ndutt
    plot(Sd(:,i),Se(:,i),'-','LineWidth',LT1out,'Color',Colore(i,:));
    hold on;
end
%Plotta la curva energetica
plot(u,eM,'-','LineWidth',LT1out,'Color',[0 0 0]);
%Plotta i punti di intersezione
plot (SolS(:,2),SolS(:,3),'s','LineWidth',LT1out*0.4,...
    'MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4); %Marca i punti in grigio
title('Energy Method "A" (1/2)','FontSize',TSout, 'FontName',FONTout);
xlabel('Displacement [m]','FontSize',ASout, 'FontName',FONTout);
ylabel('Pseudo-Energy [m^2/s^2]','FontSize',ASout, 'FontName',FONTout);
axis auto;
%axis ([0 max(u)*1.1 0 max(eM)*1.1])
grid;
saveas (figu,'Output\Fig.4.1_Energy_Method_A1.tif');
close(figu);
WB = waitbar(36/77);

%Grafico spostamento - duttilit�
fprintf (filereso,'%s \r\n','Saving Fig.4.2_Energy_Method_A2');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Plotta la curva delle duttilit� della curva di pushover
plot(u,duttM,'-','LineWidth',LT1out,'Color',[0 0 0]); %Traccia la curva in nero
hold on;
%Plotta la curva delle duttilit� spettrali
plot(SolS(:,2),SolS(:,1),'-','LineWidth',LT1out,'Color',Colore(1,:));
%Plotta il punto della soluzione
plot(SolM(1,1),SolM(1,2),'s','LineWidth',LT1out*0.4,'MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4);
title('Energy Method "A" (2/2)','FontSize',TSout, 'FontName',FONTout);
xlabel('Displacement [m]','FontSize',ASout, 'FontName',FONTout);
ylabel('Ductility [-]','FontSize',ASout, 'FontName',FONTout);
axis auto;
grid;
saveas (figu,'Output\Fig.4.2_Energy_Method_A2.tif');
close(figu);
WB = waitbar(37/77);

fprintf (filereso,'%s \r\n','Saving Energy A Method Solution');
frazM = (SolM(1,1)-u(nsolM-1))/(u(nsolM)-u(nsolM-1));
usolM = SolM(1,1);
duttsolM = SolM(1,2);
ksolM = kM(nsolM-1)+(kM(nsolM)-kM(nsolM-1))*frazM;
TsolM = TM(nsolM-1)+(TM(nsolM)-TM(nsolM-1))*frazM;
shearsolM = shear(nsolM-1,1)+(shear(nsolM,1)-shear(nsolM-1,1))*frazM;
topdispsolM = displacement(nsolM-1,nfloor)+(displacement(nsolM,nfloor)-displacement(nsolM-1,nfloor))*frazM;
WORKsolM = (WORK(nsolM,1)-WORK(nsolM-1,1))*frazM+WORK(nsolM-1,1);

%Salvataggio delle coordinate della soluzione del metodo Ordinanza
%Formato soluzione = [nome metodo/passo / max spost / duttilit� / periodo / lavoro totale / differenza]
solution(3,:) = [nsolM,usolM,duttsolM,TsolM,frazM,WORKsolM];


%Salvataggio su file della soluzione al problema
filewrite = fopen ('Output\Solutions.doc','a');
fprintf (filewrite,'%s\r\n','SOLUTION OF ENERGY "A" METHOD');
fprintf (filewrite,'%s\r\n','------------------------------------');
fprintf (filewrite,'Solution Step Number [-]   = ');
fprintf (filewrite,'%7i\r\n',nsolM-1);

fprintf (filewrite,'Fraction of Step [p]       = ');
fprintf (filewrite,'%7.2f\r\n',frazM*100);

fprintf (filewrite,'Target Displacement d* [m] = '); 
fprintf (filewrite,'%7.5f \r\n',usolM);
 
fprintf (filewrite,'Yield Displacement dy* [m] = '); 
fprintf (filewrite,'%7.5f \r\n',usolM/duttsolM); 

fprintf (filewrite,'Ductility [-]              = ');
fprintf (filewrite,'%7.4f\r\n',duttsolM);

fprintf (filewrite,'Stiffness k* [kN/m]        = ');
fprintf (filewrite,'%7.1f\r\n',ksolM);

fprintf (filewrite,'Period T* [sec]            = ');
fprintf (filewrite,'%7.4f\r\n',TsolM);
 
fprintf (filewrite,'Base Shear [kN]            = ');
fprintf (filewrite,'%7.2f\r\n',shearsolM);

fprintf (filewrite,'Max Top Displacement [m]   = ');
fprintf (filewrite,'%7.5f\r\n',topdispsolM);

fprintf (filewrite,'Total Work [kNm]           = ');
fprintf (filewrite,'%7.4f\r\n',WORKsolM);

fprintf (filewrite,'Total Mass [t]             = ');
fprintf (filewrite,'%7.2f\r\n',masstot);
 
fprintf (filewrite,'Effective Mass [t]         = ');
fprintf (filewrite,'%7.2f\r\n',massmez);

fprintf (filewrite,'Percentage Meff/Mtot [p]   = ');
fprintf (filewrite,'%7.2f\r\n',massmez/masstot*100);

fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' ');
fclose(filewrite);

fprintf (filereso,'%s \r\n',' ');

WB = waitbar(38/77);
close(WB);