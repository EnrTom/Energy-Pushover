%Modulo_0
WB = waitbar(2/77,'Reading Input');
%Fa uan preanalisi dei dati per determinare massa totale e altre cose
%Richiesta informazioni generali dell'analisi, apre il relativo file
fprintf (filereso,'%s \r\n','Read Modal Info');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Info\Info_modali.txt'],'r');
nfloor = fscanf (fileread,'%g',[1,1]);
WB = waitbar(3/77);

fprintf (filereso,'%s \r\n','Reading Masses of Structure');
%Legge la massa dei vari piani
%In realt� il Ruaumoko da i pesi sismici che vengono subito trasformati in
%masse sismiche dividendo per g
m = fscanf (fileread,'%g',[nfloor,1]);
m = m/9.81;
masstot = sum(m);
WB = waitbar(4/77);

fprintf (filereso,'%s \r\n','Reading Modal Vectro');
%Legge le forme modali
F = fscanf (fileread,'%g',[nfloor,nfloor]);
F = F';
WB = waitbar(5/77);

fprintf (filereso,'%s \r\n','Reading Period');
%Legge i valori del periodo
T = fscanf (fileread,'%g',[nfloor,1]);
fclose (fileread);
%Crea la matrice delle masse
for i = 1:nfloor
    M(i,i) = m(i);
end
%crea il vettore unitario
I(1:nfloor,1) = 1;
WB = waitbar(6/77);

fprintf (filereso,'%s \r\n','Computing Modal Parameter');
%Calcolo dei vari parametri
%Determina i fattori di partecipazione
for i = 1:nfloor
    Mi(i,1) = F(:,i)'*M*F(:,i);
    Mp(i,1) = ((F(:,i)'*M*I)^2)/Mi(i,1);
    g(i,1)  = (F(:,i)'*M*I)/Mi(i,1);
end
%calcola la massa di primo modo secondo l'EC8
masstotrid = F(:,1)'*M*I;
%calcola il fattore di partecipazione di primo modo
gamma = g(1,1);
WB = waitbar(7/77);

fprintf (filereso,'%s \r\n','Assignig Effective Mass for Energy Methods');
%qui si seleziona la massa per il metodo energetico A e B
if handles.M == 1
    masstomas = masstotrid;
    massmez = masstotrid;
elseif handles.M == 2
    masstomas = Mp(1,1);
    massmez = Mp(1,1);
elseif handles.M == 3
    masstomas = masstot;
    massmez = masstot;
end

fprintf (filereso,'%s \r\n',' ');
WB = waitbar(8/77);
close(WB);