%Modulo_7
%Riorganizzazione dei dati per la stampa finale dei risultati
WB = waitbar(44/77,'Solutions Analysis');

fprintf (filereso,'%s \r\n','Saving Methods'' Information');
%Determinazione delle grandezze corrispondenti alla soluzione dei vari metodi
%Fisso il passo della soluzione
stepOrd = solution(1,1); 
stepTom = solution(2,1);
stepMez = solution(3,1);

%Fisso la precentuale sul passo per l'interpolazione
frazOrd = solution(1,5);
frazTom = solution(2,5);
frazMez = solution(3,5);
WB = waitbar(45/77);

%Determino gli spostamenti corrrispondenti alla soluzione
fprintf (filereso,'%s \r\n','Computing Storey Displacement Solution');
dispOrd = [displacement(stepOrd,:)];
dispOrd = dispOrd';
dispTom = [displacement(stepTom-1,:)+(displacement(stepTom,:)-displacement(stepTom-1,:))*frazTom];
dispTom = dispTom';
dispMez = [displacement(stepMez-1,:)+(displacement(stepMez,:)-displacement(stepMez-1,:))*frazMez];
dispMez = dispMez';
WB = waitbar(46/77);

%Determini gli scorrimenti corrispondenti alla soluzione
fprintf (filereso,'%s \r\n','Computing Storey Drift Solution');
drifOrd(1,1) = dispOrd(1,1);
drifOrd(2:nfloor,1) = dispOrd(2:nfloor,1)-dispOrd(1:nfloor-1,1);
drifTom(1,1) = dispTom(1,1);
drifTom(2:nfloor,1) = dispTom(2:nfloor,1)-dispTom(1:nfloor-1,1);
drifMez(1,1) = dispMez(1,1);
drifMez(2:nfloor,1) = dispMez(2:nfloor,1)-dispMez(1:nfloor-1,1);
WB = waitbar(47/77);

%Determino i tagli corrrispondenti alla soluzione
fprintf (filereso,'%s \r\n','Computing Base Shear Solution');
shearOrd = shear(stepOrd,:);
shearOrd = shearOrd';
shearTom = shear(stepTom-1,:)+(shear(stepTom,:)-shear(stepTom-1,:))*frazTom;
shearTom = shearTom';
shearMez = shear(stepMez-1,:)+(shear(stepMez,:)-shear(stepMez-1,:))*frazMez;
shearMez = shearMez';
WB = waitbar(48/77);

%Carico da file i risultati della time history
fprintf (filereso,'%s \r\n','Reading Time History Displacement Solution');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Time history\',handles.CartellaAccele,'\Disp_time.txt'],'r');
dispTime = fscanf(fileread,'%g',[5,inf]);
dispTime = dispTime';
fclose (fileread);
WB = waitbar(49/77);

fprintf (filereso,'%s \r\n','Reading Time History Drift Solution');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Time history\',handles.CartellaAccele,'\Drift_time.txt'],'r');
drifTime = fscanf(fileread,'%g',[5,inf]);
drifTime = drifTime';
fclose (fileread);
WB = waitbar(50/77);

fprintf (filereso,'%s \r\n','Reading Time History Shear Solution');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Time history\',handles.CartellaAccele,'\Shear_time.txt'],'r');
shearTime = fscanf(fileread,'%g',[5,inf]);
shearTime = shearTime';
fclose (fileread);
WB = waitbar(51/77);

%Visualizzazione sulla curva di pushover delle soluzioni dei vari metodi
fprintf (filereso,'%s \r\n','Saving Fig.14_Solution_on_Push');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Plotta la soluzione del metodo EC8-N2
%Plotta la curva di pushover su cui riportare le soluzioni
plot (displacement(:,nfloor),shear(:,1),'-','LineWidth',LT1out*1.4,'Color','k');
hold on;
plot (dispOrd(nfloor,1),shearOrd(1,1),'s','LineWidth',LT1out*0.4,'MarkerEdgeColor','k','MarkerFaceColor',ColoreN2,'MarkerSize',LT1out*4);
hold on;
%Plotta la soluzione del metodo energetico "A"
plot (dispMez(nfloor,1),shearMez(1,1),'s','LineWidth',LT1out*0.4,'MarkerEdgeColor','k','MarkerFaceColor',ColoreEA,'MarkerSize',LT1out*4);
hold on
%Plotta la soluzione del metodo energetico "B"
plot (dispTom(nfloor,1),shearTom(1,1),'s','LineWidth',LT1out*0.4,'MarkerEdgeColor','k','MarkerFaceColor',ColoreEB,'MarkerSize',LT1out*4);
hold on;
%Plotta il rettangolo (o ellisse) dell'intervallo delle soluzioni
rectangle ('Curvature',[1 1],'Position',[dispTime(nfloor,4),shearTime(2,4),2*dispTime(nfloor,2),2*shearTime(2,2)],...
    'LineWidth',LT1out*0.4,'LineStyle','-','FaceColor',[0.9 0.9 0.9]);  
%Plotta la soluzione della time history
plot (dispTime(nfloor,1),shearTime(2,1),'s','LineWidth',LT1out*0.4,'MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4);
hold on;
grid;
xlabel ('Top Displacement [m]','FontSize',ASout, 'FontName',FONTout)
ylabel ('Base Shear [kN]','FontSize',ASout, 'FontName',FONTout)
title ('Methods'' Solutions on Pushover Curve','FontSize',TSout, 'FontName',FONTout);
legend ('Time History Solution','EC8-N2 Method','Energy "A" Method','Energy "B" Method','Solution Range',0);
grid;
saveas (figu,'Output\Fig.14_Solution_on_Push.tif');
close (figu);
WB = waitbar(52/77);

%Calcolo degli errori rispetto alla soluzione "vera" per gli spostamenti
%errordisp(:,1) = (dispOrd(:,1)-dispTime(:,1))./dispTime(:,1).*100;
%errordisp(:,2) = (dispTom(:,1)-dispTime(:,1))./dispTime(:,1).*100;
%errordisp(:,3) = (dispMez(:,1)-dispTime(:,1))./dispTime(:,1).*100;

%Attenzione cambaito ordine dei metodi energetici !!!!!!
fprintf (filereso,'%s \r\n','Computing Displacement Error Percentage');
errordisp(:,1) = (dispOrd(:,1)-dispTime(:,1))./dispTime(:,1).*100;
errordisp(:,2) = (dispMez(:,1)-dispTime(:,1))./dispTime(:,1).*100;
errordisp(:,3) = (dispTom(:,1)-dispTime(:,1))./dispTime(:,1).*100;
%Calcola il fattore di errore globale epsilon per i tre metodi
epsilondisp = (sum((errordisp.^2))/nfloor).^0.5;
WB = waitbar(53/77);

%Calcolo degli errori rispetto alla soluzione "vera" per gli scorrimenti
%errordrift(:,1) = (drifOrd(:,1)-drifTime(:,1))./drifTime(:,1).*100;
%errordrift(:,2) = (drifTom(:,1)-drifTime(:,1))./drifTime(:,1).*100;
%errordrift(:,3) = (drifMez(:,1)-drifTime(:,1))./drifTime(:,1).*100;

%Attenzione cambaito ordine dei metodi energetici !!!!!!
fprintf (filereso,'%s \r\n','Computing Drift Error Percentage');
errordrift(:,1) = (drifOrd(:,1)-drifTime(:,1))./drifTime(:,1).*100;
errordrift(:,2) = (drifMez(:,1)-drifTime(:,1))./drifTime(:,1).*100;
errordrift(:,3) = (drifTom(:,1)-drifTime(:,1))./drifTime(:,1).*100;
%Calcola il fattore di errore globale epsilon per i tre metodi
epsilondrift = (sum((errordrift.^2))/nfloor).^0.5;
WB = waitbar(54/77);


%Calcolo degli errori rispetto alla soluzione "vera" per il taglio alla base
%errorshear(1,1) = (shearOrd(1,1)-shearTime(2,1))./shearTime(2,1).*100;
%errorshear(1,2) = (shearTom(1,1)-shearTime(2,1))./shearTime(2,1).*100;
%errorshear(1,3) = (shearMez(1,1)-shearTime(2,1))./shearTime(2,1).*100;
fprintf (filereso,'%s \r\n','Computing Base Shear Error Percentage');
errorshear(1,1) = (shearOrd(1,1)-shearTime(2,1))./shearTime(2,1).*100;
errorshear(1,2) = (shearMez(1,1)-shearTime(2,1))./shearTime(2,1).*100;
errorshear(1,3) = (shearTom(1,1)-shearTime(2,1))./shearTime(2,1).*100;


fprintf (filereso,'%s \r\n',' ');

WB = waitbar(55/77);
close(WB);