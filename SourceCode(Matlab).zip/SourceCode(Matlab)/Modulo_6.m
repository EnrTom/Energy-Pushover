%Modulo_6
%Metodo Energetico "B" (Tomassoli)
WB = waitbar(38/77,'Computing Energy B Method');


SWB = waitbar(0,'Energy "B" Method: Processing Status');
TOTSTE = max(size(u)) + max(size(uE));
SWB = waitbar(1/TOTSTE);
fprintf (filereso,'%s \r\n','Computing Energy A Method');
%Trattamento delle curve per determinare la soluzione elastica
eE=WORKE/masstomas;
stop = 0;
for i=2:max(size(uE))
    SWB = waitbar(i/TOTSTE);
    for j=2:max(size(Sd(:,1)))
        if stop==0 
        X1 = uE(i-1);
        X2 = uE(i);
        Y1 = eE(i-1);
        Y2 = eE(i);
        Xa = Sd(j-1,1);
        Xb = Sd(j,1);
        Ya = Se(j-1,1);
        Yb = Se(j,1);
        if (X2-X1)~=0
            alfa = (Y2-Y1)/(X2-X1);
            beta = -1;
            teta = alfa*X1-Y1; 
        else
            alfa = 1;
            beta = 0;
            teta = X1;    
        end
        if (Xb-Xa)~=0
            epsilon = (Yb-Ya)/(Xb-Xa);
            delta = -1;
            fi = epsilon*Xa-Ya;
        else
            epsilon = 1;
            delta = 0;
            fi = Y1;
        end        
        A = [alfa beta;epsilon delta];
        B = [teta;fi];
        if det(A)~=0
            S = inv(A)*B;
            Sx = S(1,1);
            Sy = S(2,1);
            if abs(X2-X1)>=abs(Sx-X1) &...
               abs(Xb-Xa)>=abs(Sx-Xa) &...
               abs(Y2-Y1)>=abs(Sy-Y1) &...
               abs(Yb-Ya)>=abs(Sy-Ya)    
               SolE = [Sx,Sy];
               nsolE = j;  
               stop = 1;
            end
        end
    end
end
end

if Sd(nsolE-1,1)~=Sd(nsolE,1)
    frazE = abs(Sx-Sd(nsolE-1,1))/(Sd(nsolE,1)-Sd(nsolE-1,1));
else 
    frazE = abs(Sy-Se(nsolE-1,1))/(Se(nsolE,1)-Se(nsolE-1,1));
end
Tsol = period(nsolE-1,1)+(period(nsolE,1)-period(nsolE-1,1))*frazE;

%calculate elastic shear solution
shearEsol = SolE(1,1)*((2*pi/Tsol)^2)*1;

%WB = waitbar(39/77);

fprintf (filereso,'%s \r\n','Computing Iso-Period Curve');
%Determinazione della curva a periodo costante
for i=1:ndutt
    xTcost(i,1) = (Sd(nsolE,i)-Sd(nsolE-1,i))*frazE+Sd(nsolE-1,i);
    yTcost(i,1) = (Se(nsolE,i)-Se(nsolE-1,i))*frazE+Se(nsolE-1,i);
end
WB = waitbar(40/77);

fprintf (filereso,'%s \r\n','Computing Intersection Curve-Spectra');
%Tracciamento della curva elasto-plastica e determinazione della soluzione
e=WORK/masstomas;
stop = 0;
Sol = [];
for i=2:max(size(u))
    SWB = waitbar(i + max(size(uE))/TOTSTE);
    for j=2:max(size(xTcost))
        if stop==0 
        X1 = u(i-1);
        X2 = u(i);
        Y1 = e(i-1);
        Y2 = e(i);
        Xa = xTcost(j-1,1);
        Xb = xTcost(j,1);
        Ya = yTcost(j-1,1);
        Yb = yTcost(j,1);
        if (X2-X1)~=0
            alfa = (Y2-Y1)/(X2-X1);
            beta = -1;
            teta = alfa*X1-Y1; 
        else
            alfa = 1;
            beta = 0;
            teta = X1;    
        end
        if (Xb-Xa)~=0
            epsilon = (Yb-Ya)/(Xb-Xa);
            delta = -1;
            fi = epsilon*Xa-Ya;
        else
            epsilon = 1;
            delta = 0;
            fi = Y1;
        end        
        A = [alfa beta;epsilon delta];
        B = [teta;fi];
        if det(A)~=0
            S = inv(A)*B;
            Sx = S(1,1);
            Sy = S(2,1);
            if abs(X2-X1)>=abs(Sx-X1) &...
               abs(Xb-Xa)>=abs(Sx-Xa) &...
               abs(Y2-Y1)>=abs(Sy-Y1) &...
               abs(Yb-Ya)>=abs(Sy-Ya)    
               Sol = [Sx,Sy];
               nsol = i;
               nTsol = j;
               stop = 1;
            end
        end
    end
end
end

size(Sol);
if ans(1,1) == 0
    Sol = [0,0]
    Sx = 0;
    Sy = 0;
    nsol = 2
    nTsol = 2
end

if u(nsol,1)~=u(nsol-1,1)
    fraz = abs((Sx-u(nsol-1,1))/(u(nsol,1)-u(nsol-1,1)));
else
    fraz = abs((Sy-e(nsol-1,1))/(e(nsol,1)-e(nsol-1,1)));
end

if xTcost(nTsol,1)~=xTcost(nTsol-1,1)
    frazT = abs((Sx-xTcost(nTsol-1,1))/(xTcost(nTsol,1)-xTcost(nTsol-1,1)));
else
    frazT = abs((Sx-yTcost(nTsol-1,1))/(yTcost(nTsol,1)-yTcost(nTsol-1,1)));
end
WB = waitbar(41/77);
close(SWB);

fprintf (filereso,'%s \r\n','Saving Energy B Method Parameters');
%Calcola le soluzioni esatte del metodo
%duttisol = (duttility(1,nTsol)-duttility(1,nTsol-1))*frazT+duttility(nTsol-1);
ksol = ((2*pi/Tsol)^2)*masstomas;
shearsol = (shear(nsol,1)-shear(nsol-1,1))*fraz+shear(nsol-1,1);
displsol = (displacement(nsol,nfloor)-displacement(nsol-1,nfloor))*fraz+displacement(nsol-1,nfloor);
usol = (u(nsol,1)-u(nsol-1,1))*fraz+u(nsol-1,1);
uysol = shearsol./ksol;
duttisol = usol./uysol;
WORKsol = (WORK(nsol,1)-WORK(nsol-1,1))*fraz+WORK(nsol-1,1);
WB = waitbar(42/77);
Rsol = (shearEsol.*masstomas)./shearsol;


%Plotta ma metodologia
fprintf (filereso,'%s \r\n','Saving Fig.5.1_Energy_Method_B');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Plotta gli spettri
for i = 1:ndutt
    plot (Sd(:,i),Se(:,i),'-','LineWidth',LT1out,'Color',Colore(i,:));
    hold on;
end
%Plottal la curva energetica elastica
plot (uE,eE,'-','LineWidth',LT1out,'Color',[0.4 0.4 0.4]); %Stampa la curva in grigio scuro
%Plotta la curva spettrale a periodo costante
plot (xTcost,yTcost,'--','LineWidth',LT1out,'Color','k');
%plotta la curva energetica elasto-plastica
plot (u,e,'-','LineWidth',LT1out,'Color',[0 0 0]);  %Stampa la curva in nero
%Plotta il punto notevole elastico
plot(xTcost(1),yTcost(1),'-s','LineWidth',LT1out*0.4,...
'MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4); %Marca i punti in grigio
%Plotta il punto notevole soluzione
plot(usol,WORKsol/masstomas,'-s','LineWidth',LT1out*0.4,...
'MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4); %Marca i punti in grigio
grid;
axis auto;
%axis ([0 max(max(Sd)) 0 max(max(Se))]);
title ('Energy Method "B"','FontSize',TSout, 'FontName',FONTout);
xlabel('Displacement [m]','FontSize',ASout, 'FontName',FONTout);
ylabel('Pseudo-Energy [m^2/2^2]','FontSize',ASout, 'FontName',FONTout);
saveas (figu,'Output\Fig.5.1_Energy_Method_B.tif');
close(figu);
WB = waitbar(43/77);


fprintf (filereso,'%s \r\n','Saving Energy B Method Solution');
%Salvataggio su file della soluzione al problema
filewrite = fopen ('Output\Solutions.doc','a');
fprintf (filewrite,'%s\r\n','SOLUTION OF ENERGY "B" METHOD');
fprintf (filewrite,'%s\r\n','------------------------------------');
fprintf (filewrite,'Solution Step Number [-]   = ');
fprintf (filewrite,'%7i\r\n',nsol-1);

fprintf (filewrite,'Fraction of Step [p]       = ');
fprintf (filewrite,'%7.2f\r\n',fraz*100);

fprintf (filewrite,'Target Displacement d* [m] = '); 
fprintf (filewrite,'%7.5f \r\n',usol); 

fprintf (filewrite,'Yield Displacement dy* [m] = '); 
fprintf (filewrite,'%7.5f \r\n',uysol);

fprintf (filewrite,'Reduction Factor R* [-]    = ');
fprintf (filewrite,'%7.4f\r\n',Rsol);

fprintf (filewrite,'Ductility [-]              = ');
fprintf (filewrite,'%7.4f\r\n',duttisol);

fprintf (filewrite,'Stiffness k* [kN/m]        = ');
fprintf (filewrite,'%7.1f\r\n',ksol);

fprintf (filewrite,'Period T* [sec]            = ');
fprintf (filewrite,'%7.4f\r\n',Tsol);

fprintf (filewrite,'Base Shear [kN]            = ');
fprintf (filewrite,'%7.2f\r\n',shearsol);

fprintf (filewrite,'Elastic Base Shear [kN]    = ');
fprintf (filewrite,'%7.2f\r\n',shearEsol.*masstomas);

fprintf (filewrite,'Max Top Displacement [m]   = ');
fprintf (filewrite,'%7.5f\r\n',displsol);

fprintf (filewrite,'Total Work [kNm]           = ');
fprintf (filewrite,'%7.4f\r\n',WORKsol);

fprintf (filewrite,'Total Mass [t]             = ');
fprintf (filewrite,'%7.2f\r\n',masstot);

fprintf (filewrite,'Effective Mass [t]         = ');
fprintf (filewrite,'%7.2f\r\n',masstomas);

fprintf (filewrite,'Percentage Meff/Mtot [p]   = ');
fprintf (filewrite,'%7.2f\r\n',masstomas/masstot*100);

fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' ');
fclose(filewrite);

%Salvataggio delle coordinate della soluzione metodo Tomassoli
%Formato soluzione = [mone metodo/passo / max spost / duttilit� / periodo/ lavoro totale / percentuale passo]
solution(2,:) = [nsol,usol,duttisol,Tsol,fraz,WORKsol];

fprintf (filereso,'%s \r\n',' ');

WB = waitbar(44/77);
close(WB);



