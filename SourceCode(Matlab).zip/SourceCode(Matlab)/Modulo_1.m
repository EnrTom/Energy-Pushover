%MODULO 1
WB = waitbar(8/77,'Reading Input');
%Lettura dei file di ingresso da elaborare
%Dichiara le variabili globali cosi da usarle anche per altre operazioni
%global nstep nstepE nfloor displacement displacementE shear shearE  

%Lettura dati input da file curva elasto-plastica
%Lettura spostamenti
fprintf (filereso,'%s \r\n','Reading Storey Displacement (non linear case)');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Pushover\',handles.CartellaPush,'\disp_EP.txt'],'r');
displacement = fscanf(fileread,'%g',[(nfloor+1),inf]);
displacement = displacement';
displacement(:,1) = [ ];
fclose (fileread);
WB = waitbar(9/77);
%Lettura tagli di piano
fprintf (filereso,'%s \r\n','Reading Storey Shear (non linear case)');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Pushover\',handles.CartellaPush,'\shear_EP.txt'],'r');
shear = fscanf (fileread,'%g',[(nfloor+1),inf]);
shear = shear';
shear(:,1) = [ ];
fclose (fileread);
nstep=max(size(displacement));
WB = waitbar(10/77);

%Lettura dati input da file curva elastica
%Lettura spostamenti
fprintf (filereso,'%s \r\n','Reading Storey Displacement (linear case)');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Pushover\',handles.CartellaPush,'\disp_E.txt'],'r');
displacementE = fscanf(fileread,'%g',[(nfloor+1),inf]);
displacementE = displacementE';
displacementE(:,1) = [ ];
fclose (fileread);
WB = waitbar(11/77);

%Lettura tagli di piano
fprintf (filereso,'%s \r\n','Reading Storey Shear (linear case)');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Pushover\',handles.CartellaPush,'\shear_E.txt'],'r');
shearE = fscanf (fileread,'%g',[(nfloor+1),inf]);
shearE = shearE';
shearE(:,1) = [ ];
fclose (fileread);
nstepE=size(displacementE);
WB = waitbar(12/77);

%Graficizzazione dei dati letti (solo curva elasto-plastica)
%Colori util. =   1   2   3   4   5   6   7   8
color = str2mat('b','g','r','y','m','c','w','k'); 
MaxX = max(max(displacement(1:nstep,1:(nfloor))));
MaxY = max(max(shear(1:nstep,1:(nfloor))));


%Salva il grafico nel fine di output
%Non fa vedere la figura
fprintf (filereso,'%s \r\n','Saving Fig.1.1_Pushover_Curve');
figu = figure ('Visible','off');
%Imposta gli assi del grafico
axes('FontSize',ANSout,'FontName',FONTout);
%plotta i grafici richiesti
plot (displacement(1:nstep,nfloor),shear(1:nstep,1),'-','LineWidth',LT1out*1.4,'Color','k');
%Imposta i limiti degli assi del grafico
axis auto;
%Da il nome all'asse delle X e delle Y
xlabel('Top Displacement [m]','FontSize',ASout, 'FontName',FONTout)
ylabel('Base Shear [kN]','FontSize',ASout, 'FontName',FONTout)
%Da il nome al titolo del grafico
title ([handles.NomePush,' Pushover Curve'],'FontSize',TSout, 'FontName',FONTout);
%Mette la griglia;
grid;
%Salva il file nella cartella di output
saveas(figu,'Output\Fig.1.1_Pushover_Curve.tif');
%print -dbmp16m Output\Fig.1.1_Pushover_Curve.bmp;
%print -dtiff Output\Fig.1.1_Pushover_Curve.tif;
%Chiude la figura
close(figu);
fprintf (filereso,'%s \r\n',' ');

WB = waitbar(13/77);
close(WB);