function varargout = PE(varargin)
% PE M-file for PE.fig
%      PE, by itself, creates a new PE or raises the existing
%      singleton*.
%
%      H = PE returns the handle to a new PE or the handle to
%      the existing singleton*.
%
%      PE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PE.M with the given input arguments.
%
%      PE('Property','Value',...) creates a new PE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PE_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PE_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help PE

% Last Modified by GUIDE v2.5 24-Jan-2011 16:45:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PE_OpeningFcn, ...
                   'gui_OutputFcn',  @PE_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before PE is made visible.
function PE_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PE (see VARARGIN)

% Choose default command line output for PE
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PE wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PE_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function PanelPush_SelectionChangeFcn(hObject, eventdata, handles)
%Si seleziona il tipo di pushover da fare
if get(handles.radiobutton1,'Value') == get(handles.radiobutton1,'Max')
    handles.CartellaPush = 'Modale';
    handles.NomePush = 'Modal';
elseif get(handles.radiobutton2,'Value') == get(handles.radiobutton1,'Max')
    handles.CartellaPush = 'Uniforme';
    handles.NomePush = 'Uniform';
elseif get(handles.radiobutton3,'Value') == get(handles.radiobutton1,'Max')
    handles.CartellaPush = 'Adattiva';
    handles.NomePush = 'Adaptive';
elseif get(handles.radiobutton4,'Value') == get(handles.radiobutton1,'Max')
    handles.CartellaPush = 'Multimodale';
    handles.NomePush = 'Multimodal';
end
guidata(hObject, handles);


% --------------------------------------------------------------------
function PanelSpectra_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to PanelSpectra (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Si seleziona il tipo di pushover da fare
if get(handles.radiobuttonSNor,'Value') == get(handles.radiobuttonSNor,'Max')
    handles.CartellaSpectra= 'Normativi';
elseif get(handles.radiobuttonSGen,'Value') == get(handles.radiobuttonSGen,'Max')
    handles.CartellaSpectra= 'Generati';
elseif get(handles.radiobuttonSReg,'Value') == get(handles.radiobuttonSReg,'Max')
    handles.CartellaSpectra= 'Registrati';
end
guidata(hObject, handles);



% --------------------------------------------------------------------
function PanelAccel_SelectionChangeFcn(hObject, eventdata, handles)
%qui si selezionano i gruppi di accelerogrammi
if get(handles.radiobuttonAGen,'Value') == get(handles.radiobuttonAGen,'Max')
    handles.CartellaAccele = 'Generati';
elseif get(handles.radiobuttonAReg,'Value') == get(handles.radiobuttonAReg,'Max')
    handles.CartellaAccele = 'Registrati';
end    
guidata(hObject, handles);


% --------------------------------------------------------------------
function PanelMas_SelectionChangeFcn(hObject, eventdata, handles)
if get(handles.radiobuttonM1,'Value') == get(handles.radiobuttonM1,'Max')
    handles.M = 1;
elseif get(handles.radiobuttonM2,'Value') == get(handles.radiobuttonM2,'Max')
    handles.M = 2;
elseif get(handles.radiobuttonM3,'Value') == get(handles.radiobuttonM3,'Max')
    handles.M = 3;
end
guidata(hObject, handles);



% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
%si seleziona il modello
if get(handles.popupmenu1,'Value') == 1
    %serve solo per i warning !!!
    set(handles.NomeModello,'Value','Min');
elseif get(handles.popupmenu1,'Value') == 2
    handles.NomeModello = 'Alfa';
elseif get(handles.popupmenu1,'Value') == 3
    handles.NomeModello = 'Beta';
elseif get(handles.popupmenu1,'Value') == 4
    handles.NomeModello = 'Gamma';
elseif get(handles.popupmenu1,'Value') == 5
    handles.NomeModello = 'Delta';
elseif get(handles.popupmenu1,'Value') == 6
    handles.NomeModello = 'Epsilon (+)';
elseif get(handles.popupmenu1,'Value') == 7
    handles.NomeModello = 'Epsilon (-)';
elseif get(handles.popupmenu1,'Value') == 8
    %Questo serve se si volessero fare analisi su modello non presente nel database 
    handles.NomeModello = 'User';
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in Calcolametodi.
function Calcolametodi_Callback(hObject, eventdata, handles)

%serve per cancellare tutti i grafici per sostituirli dopo
axes(handles.axesPdisp);
cla reset;
axes(handles.axesPdrift);
cla reset;
axes(handles.axesPshear);
cla reset;
axes(handles.axesDisp);
cla reset;
axes(handles.axesDrift);
cla reset;
axes(handles.axesPush);
cla reset;


%Serve per avvisare che manca qualche selezione !!!
MESS = 0;
messaggio = ['SELECT:            ';'                   '];

%Controllo della selezione modello e relativo messaggio di errore
if get(handles.popupmenu1,'Value') == 1
    messaggio = [messaggio;'Model;             '];
    MESS = -1;
end
%Controllo della selezione caso pushover e relativo messaggio di errore
CP = get(handles.radiobutton1,'Value')+get(handles.radiobutton2,'Value')+...
     get(handles.radiobutton3,'Value')+get(handles.radiobutton4,'Value');
if CP == 0                 
    messaggio = [messaggio;'Pushover Case;     '];
    MESS = -1;
end
%Controllo della selezione spettro e relativo messaggio di errore
CS = get(handles.radiobuttonSNor,'Value')+get(handles.radiobuttonSGen,'Value')+...
     get(handles.radiobuttonSReg,'Value');
if CS == 0                 
    messaggio = [messaggio;'Spectra;           '];
    MESS = -1;
end
%Controllo della selezione accelerogrammi e relativo messaggio di errore
CA = get(handles.radiobuttonAGen,'Value')+get(handles.radiobuttonAReg,'Value');
if CA == 0                 
    messaggio = [messaggio;'Accelerogram Group;'];
    MESS = -1;
end
%Controllo della selezione massa e relativo messaggio di errore
CM = get(handles.radiobuttonM1,'Value')+get(handles.radiobuttonM2,'Value')+...
    get(handles.radiobuttonM3,'Value');
if CM == 0                 
    messaggio = [messaggio;'Effective Mass;    '];
    MESS = -1; 
end
if MESS == -1
    msgbox (messaggio,'Warning','warn');
    pause;
end


%Serve per valutare se spettri e accelerogrammi sono compatibili
Me = -1;
if get(handles.radiobuttonSNor,'Value') == get(handles.radiobuttonSNor,'Max')
    Me = 0;
elseif get(handles.radiobuttonSGen,'Value') == get(handles.radiobuttonAGen,'Value')
    Me = 0;
end

if Me == -1
    msgbox ('Spectra and Accelerogram must be coherent','Warning','warn');
    pause;
end

%Crea un file di output in cui si scrive l'operazione che verr� fatta cosi
%da trovare eventuali errori nel programma quando si blocca
filereso = fopen ('Output\Check_program.txt','w');
fprintf (filereso,'%s \r\n','Program RUN - Start');
statime = clock;
fprintf (filereso,'%s \r\n',datestr(now));
fprintf (filereso,'%s \r\n',' ')

%Setta i parametri del programma
fprintf (filereso,'%s \r\n','Setup Output Graphics');
WB = waitbar(0,'Starting Computing ...');
close(WB);
Setup_graphics;
fprintf (filereso,'%s \r\n','Setup Video Output');
Setup_program;
fprintf (filereso,'%s \r\n',' ');
%Legge i file di ingresso
fprintf (filereso,'%s \r\n','Run Modulo_0');
Modulo_0;  %Lettura info modali, massa, numero piano ecc.
fprintf (filereso,'%s \r\n','Run Modulo_1');
Modulo_1;  %Lettura curva pushover e plottaggio
%Riporta le info nel pannello delle info modello
set(handles.textNfloor,'String',num2str(nfloor));
set(handles.textT,'String',[num2str(chop(T(1,1),3)),' s']);
set(handles.textMtot,'String',[num2str(chop(masstot,4)),' t']);
set(handles.textMast,'String',[num2str(chop(masstotrid,4)),' t - (',num2str(chop((masstotrid/masstot*100),3)),' %)']);
set(handles.textMeff,'String',[num2str(chop(masstomas,4)),' t - (',num2str(chop((masstomas/masstot*100),3)),' %)']);
fprintf (filereso,'%s \r\n','Run Modulo_2');
Modulo_2;  %Elabora la curva e ne calcola l'energia
fprintf (filereso,'%s \r\n','Run Modulo_3');
Modulo_3;  %Legge gli spettri di PsA, Sd e PsE
fprintf (filereso,'%s \r\n','Run Modulo_4');
Modulo_4;  %Metodo EC8-N2
fprintf (filereso,'%s \r\n','Run Modulo_5');
Modulo_5;  %Metodo energetico A
fprintf (filereso,'%s \r\n','Run Modulo_6');
Modulo_6;  %Metodo energetico B
fprintf (filereso,'%s \r\n','Run Modulo_7');
Modulo_7;  %Riorganizzazione dei dati per la stampa
fprintf (filereso,'%s \r\n','Run Modulo_8');
Modulo_8;  %Stampa dei risultati finali
fprintf (filereso,'%s \r\n','Run Modulo_9');
Modulo_9;  %Stampa su file dei risultati;
fprintf (filereso,'%s \r\n','Run Modulo_10');
Modulo_10; %Stampa a video tutti i risultati importanti
fprintf (filereso,'%s \r\n','Run Modulo_11');
Modulo_11; %Riporta in tabella i risultati globali
guidata(hObject, handles);

Modulo_12; %Serve per altre cose

%Chiude il file del resoconto di quanto fatto sopra
close(WB);
WB = waitbar(77/77,'Finish');
fprintf (filereso,'%s \r\n','Program RUN - Finish');
fprintf (filereso,'%s \r\n',datestr(Now));
fintime = clock;
fprintf (filereso,'%s \r\n',['Analisys Time = ',num2str(etime(fintime,statime)),' s']);
fclose(filereso);
WB = waitbar(1);
close(WB);


function editSN_Callback(hObject, eventdata, handles)
% hObject    handle to editSN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSN as text
%        str2double(get(hObject,'String')) returns contents of editSN as a double


% --- Executes during object creation, after setting all properties.
function editSN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editSA_Callback(hObject, eventdata, handles)
% hObject    handle to editSA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSA as text
%        str2double(get(hObject,'String')) returns contents of editSA as a double


% --- Executes during object creation, after setting all properties.
function editSA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editSB_Callback(hObject, eventdata, handles)
% hObject    handle to editSB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSB as text
%        str2double(get(hObject,'String')) returns contents of editSB as a double


% --- Executes during object creation, after setting all properties.
function editSB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double


% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function editDN_Callback(hObject, eventdata, handles)
% hObject    handle to editDN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editDN as text
%        str2double(get(hObject,'String')) returns contents of editDN as a double


% --- Executes during object creation, after setting all properties.
function editDN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editDN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editDA_Callback(hObject, eventdata, handles)
% hObject    handle to editDA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editDA as text
%        str2double(get(hObject,'String')) returns contents of editDA as a double


% --- Executes during object creation, after setting all properties.
function editDA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editDA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editDB_Callback(hObject, eventdata, handles)
% hObject    handle to editDB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editDB as text
%        str2double(get(hObject,'String')) returns contents of editDB as a double


% --- Executes during object creation, after setting all properties.
function editDB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editDB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editVN_Callback(hObject, eventdata, handles)
% hObject    handle to editVN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editVN as text
%        str2double(get(hObject,'String')) returns contents of editVN as a double


% --- Executes during object creation, after setting all properties.
function editVN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editVN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editVA_Callback(hObject, eventdata, handles)
% hObject    handle to editVA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editVA as text
%        str2double(get(hObject,'String')) returns contents of editVA as a double


% --- Executes during object creation, after setting all properties.
function editVA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editVA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editVB_Callback(hObject, eventdata, handles)
% hObject    handle to editVB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editVB as text
%        str2double(get(hObject,'String')) returns contents of editVB as a double


% --- Executes during object creation, after setting all properties.
function editVB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editVB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



%Procedura per la chiamata delle immagini dello spettro
function pushbutton6_Callback(hObject, eventdata, handles)
imview('Output\Fig.2.1_Displacement_spectra.tif');

function pushbutton7_Callback(hObject, eventdata, handles)
imview('Output\Fig.2.2_Ps-acceleration_Spectra.tif');

function pushbutton8_Callback(hObject, eventdata, handles)
imview('Output\Fig.2.3_Ps-energy_Spectra.tif');

function pushbutton9_Callback(hObject, eventdata, handles)
imview('Output\Fig.2.4_Ps-energy_vs_Displacement_Spectra.tif');



%Procedura per la chiamata delle immagini delle metodologie
function pushbutton10_Callback(hObject, eventdata, handles)
imview('Output\Fig.3.2_EC8-N2_Method.tif');

function pushbutton11_Callback(hObject, eventdata, handles)
imview('Output\Fig.4.1_Energy_Method_A1.tif');

function pushbutton12_Callback(hObject, eventdata, handles)
imview('Output\Fig.4.2_Energy_Method_A2.tif');

function pushbutton13_Callback(hObject, eventdata, handles)
imview('Output\Fig.5.1_Energy_Method_B.tif');

function pushbutton19_Callback(hObject, eventdata, handles)
imview('Output\Fig.6.8_Cfr_SDOF.tif');



%Procedura per la chiamata delle immagini dello zoom dei grafici
function pushbutton14_Callback(hObject, eventdata, handles)
imview('Output\Fig.6.3_Cfr_disp_perc.tif');

function pushbutton15_Callback(hObject, eventdata, handles)
imview('Output\Fig.6.5_Cfr_disp_perc.tif');

function pushbutton16_Callback(hObject, eventdata, handles)
imview('Output\Fig.6.7_Cfr_Shear_Perc.tif');

function pushbutton17_Callback(hObject, eventdata, handles)
imview('Output\Fig.6.2_Cfr_disp_def.tif');

function pushbutton18_Callback(hObject, eventdata, handles)
imview('Output\Fig.6.4_Cfr_drift_def.tif');

%Procedura per la chiamata del file numerico dei risultati


function pushbutton20_Callback(hObject, eventdata, handles)
open('Output\Solutions.doc');

function pushbutton4_Callback(hObject, eventdata, handles)
open(['Database\Modello ',handles.NomeModello,'\Info\Dati_modello.doc']);

function pushbutton5_Callback(hObject, eventdata, handles)
open(['Database\Modello ',handles.NomeModello,'\Info\Modello.pdf']);


% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


