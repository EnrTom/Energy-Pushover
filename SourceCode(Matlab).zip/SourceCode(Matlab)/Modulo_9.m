
%Modulo_9
%Salvataggio su file dei dati numerici delle analisi
WB = waitbar(62/77,'Saving Results');

fileread = fopen ('Output\Solutions.doc','a');
%Aggiunge righe vuote solo per una impaginazione nel file di uscita
for i = 1:4
    fprintf (filewrite,'%s\r\n',' ');
end
fprintf (filereso,'%s\r\n','Saving Storey Displacement in File');
fprintf (filewrite,'%s\r\n','STOREY DISPLACEMENT');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n','  No.   EC8-N2   Energy A  Energy B    Time       COV');
fprintf (filewrite,'%s\r\n',' Floor  Method    Method    Method    History     (%)');
fprintf (filewrite,'%s\r\n','-------------------------------------------------------');
D = [];
D(1:nfloor,1) = (linspace(1,nfloor,nfloor))';
D = [D,dispOrd,dispMez,dispTom,dispTime(:,1),dispTime(:,3)*100];
fprintf (filewrite,'%4i %9.4f %9.4f %9.4f %9.4f %9.2f\r\n',D');
fprintf (filewrite,'%s\r\n',' ');
WB = waitbar(63/77);
fprintf (filereso,'%s\r\n','Saving Storey Displacement Error in File');

fprintf (filewrite,'%s\r\n','STOREY DISPLACEMENT ERROR PERCENTAGE');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n','  No.   EC8-N2   Energy A  Energy B ');
fprintf (filewrite,'%s\r\n',' Floor  Method    Method    Method');
fprintf (filewrite,'%s\r\n','------------------------------------');
E = [];
E(1:nfloor,1) = (linspace(1,nfloor,nfloor))';
E = [E,errordisp];
fprintf (filewrite,'%4i %9.2f %9.2f %9.2f \r\n',E');
fprintf (filewrite,'%s\r\n','------------------------------------');
fprintf (filewrite,'%5s %8.2f %9.2f %9.2f \r\n','  tot',epsilondisp);
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' ');
fclose (filewrite);
WB = waitbar(64/77);




fprintf (filereso,'%s\r\n','Saving Storey Drift in File');
fileread = fopen ('Output\Solutions.doc','a');
fprintf (filewrite,'%s\r\n','STOREY DRIFT');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n','  No.   EC8-N2   Energy A  Energy B    Time       COV');
fprintf (filewrite,'%s\r\n',' Floor  Method    Method    Method    History     (%)');
fprintf (filewrite,'%s\r\n','-------------------------------------------------------');
F = [];
F(1:nfloor,1) = (linspace(1,nfloor,nfloor))';
F = [F,drifOrd,drifMez,drifTom,drifTime(:,1),drifTime(:,3)*100];
fprintf (filewrite,'%4i %9.4f %9.4f %9.4f %9.4f %9.2f \r\n',F');

fprintf (filewrite,'%s\r\n',' ');
WB = waitbar(65/77);
fprintf (filereso,'%s\r\n','Saving Storey Drift Error in File');
fprintf (filewrite,'%s\r\n','STOREY DRIFT ERROR PERCENTAGE');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n','  No.   EC8-N2   Energy A  Energy B ');
fprintf (filewrite,'%s\r\n',' Floor  Method    Method    Method');
fprintf (filewrite,'%s\r\n','------------------------------------');
G = [];
G(1:nfloor,1) = (linspace(1,nfloor,nfloor))';
G = [G,errordrift];
fprintf (filewrite,'%4i %9.2f %9.2f %9.2f \r\n',G');
fprintf (filewrite,'%s\r\n','------------------------------------');
fprintf (filewrite,'%5s %8.2f %9.2f %9.2f \r\n','  tot',epsilondrift);
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' ');
fclose (filewrite);
WB = waitbar(66/77);



fprintf (filereso,'%s\r\n','Saving Base Shear in File');
fileread = fopen ('Output\Solutions.doc','a');
fprintf (filewrite,'%s\r\n','BASE SHEAR');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' Anal.  EC8-N2   Energy A  Energy B    Time       COV');
fprintf (filewrite,'%s\r\n',' Type   Method    Method    Method    History     (%)');
fprintf (filewrite,'%s\r\n','-------------------------------------------------------');
H = [];
H = [shearOrd(1,1),shearMez(1,1),shearTom(1,1),shearTime(2,1),shearTime(2,3)*100];
fprintf (filewrite,'%5s %8.2f %9s %9.2f %9.2f %9.2f\r\n', '  Ela',(yyy.*masstotrid.*gamma),'   -   ',shearEsol,shearTime(1,1),shearTime(1,3)*100);
fprintf (filewrite,'%5s %8.2f %9.2f %9.2f %9.2f %9.2f\r\n','  Pla',H');
fprintf (filewrite,'%s\r\n','-------------------------------------------------------');
fprintf (filewrite,'%4s %8.2f %9s %9.2f %9.2f %10.2f\r\n',' R',qq,'      -  ',(shearEsol./shearsol),shearTime(3,1),shearTime(3,3)*100);

fprintf (filewrite,'%s\r\n',' ');
fprintf (filereso,'%s\r\n','Saving Base Shear Error in File');
WB = waitbar(67/77);
fprintf (filewrite,'%s\r\n','BASE SHEAR ERROR PERCENTAGE');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' Anal.  EC8-N2   Energy A  Energy B');
fprintf (filewrite,'%s\r\n',' Type   Method    Method    Method');
fprintf (filewrite,'%s\r\n','------------------------------------');
I = [];
I = [errorshear];
fprintf (filewrite,'%5s %8.2f %9.2f %9.2f \r\n','  Pla',I');
fclose (filewrite);

fprintf (filereso,'%s\r\n',' ');
WB = waitbar(68/77);
close(WB);