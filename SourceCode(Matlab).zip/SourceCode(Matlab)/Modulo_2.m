%Modulo_2

WB = waitbar(13/77,'Model Analysis');

%INIZIO ELABORAZIONE CURVE ENERGIA ***
%Trattamento dei dati per costruzione delle curve per i metodi
fprintf (filereso,'%s \r\n','Computing Storey Force (non linear case)');
%Calcolo delle curve nel caso elasto-plastico
%Calcolo delle forze ai vari piani
forces(1:nstep,1:nfloor-1)=shear(1:nstep,1:(nfloor-1))-shear(1:nstep,2:nfloor);
forces(1:nstep,nfloor)=shear(1:nstep,nfloor);
WB = waitbar(14/77);

fprintf (filereso,'%s \r\n','Computing Work (non linear case)');
%Calcolo del lavoro fatto dalle forze sulla struttura ai vari piani
deWORK(1,1:nfloor) = 0;
deWORK(2:nstep,1:nfloor) = (forces(2:nstep,1:nfloor)+forces(1:nstep-1,1:nfloor)).*...
    (displacement(2:nstep,1:nfloor)-displacement(1:nstep-1,1:nfloor))./2;
deWORKtot = (sum(deWORK'))';

%qui calcola lo spsotamento equienergetico solo per edifici a pi� piani
deu(1,1) = 0;
deu(2:nstep,1) = deWORKtot(2:nstep,1)./((shear(2:nstep,1)+shear(1:nstep-1,1))./2);

WORK(1,1) = 0;
u(1) = 0;
for k=2:nstep
    WORK(k) = WORK(k-1)+deWORKtot(k);
    u(k) = u(k-1)+deu(k);
end
WORK = WORK';
u = u';
WB = waitbar(15/77);

%Calcolo delle curve nel caso elastico
%Calcolo delle forze ai vari piani
fprintf (filereso,'%s \r\n','Computing Storey Force (linear case)');
forcesE(1:nstepE,1:nfloor-1)=shearE(1:nstepE,1:(nfloor-1))-shearE(1:nstepE,2:nfloor);
forcesE(1:nstepE,nfloor)=shearE(1:nstepE,nfloor);
WB = waitbar(16/77);

%Calcolo del lavoro fatto dalle forze sulla struttura ai vari piani
fprintf (filereso,'%s \r\n','Computing Work (linear case)');
deWORKE(1,1:nfloor) = 0;
deWORKE(2:nstepE,1:nfloor) = (forcesE(2:nstepE,1:nfloor)+forcesE(1:nstepE-1,1:nfloor)).*...
    (displacementE(2:nstepE,1:nfloor)-displacementE(1:nstepE-1,1:nfloor))./2;
deWORKtotE = (sum(deWORKE'))';
deuE(1,1) = 0;
deuE(2:nstepE,1) = deWORKtotE(2:nstepE,1)./((shearE(2:nstepE,1)+shearE(1:nstepE-1,1))./2);
WORKE(1) = 0;
uE(1) = 0;
for k=2:nstepE
    WORKE(k) = WORKE(k-1)+deWORKtotE(k);
    uE(k) = uE(k-1)+deuE(k);
end
WORKE = WORKE';
uE = uE';
WB = waitbar(17/77);

%Grafico della curva di pushover energetica (elasto-plastica + elastica)
fprintf (filereso,'%s \r\n','Saving Fig.1.2_Shear_curves');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
plot (u,shear(:,1),'LineWidth',LT1out,'Color',[0 0 0]);  %Colora la curva di nero
hold on;
plot (uE,shearE(:,1),'-','LineWidth',LT1out,'Color',[0.4 0.4 0.4]);  %Colora la curva di grigio
axis auto;
%axis ([0  max(max(u),max(uE))*1.10  0   max(max(shear(:,1)),max(shearE(:,1)))*1.1]);
xlabel('Energy Displacement [m]','FontSize',ASout, 'FontName',FONTout)
ylabel ('Base Shear [kN]','FontSize',ASout, 'FontName',FONTout)
title ([handles.NomePush,' Pushover Curves'],'FontSize',TSout, 'FontName',FONTout);
grid;
legend(' Elastic',' Elasto-Plastic ','FontSize',ASout,'FontName',FONTout','Location','NorthWest');
saveas(figu,'Output\Fig.1.2_Shear_curves.tif');
close(figu);
WB = waitbar(18/77);


fprintf (filereso,'%s \r\n','Saving Fig.1.3_Energy_curves');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
plot (u,WORK,'LineWidth',LT1out,'Color',[0 0 0]);
hold on;
plot (uE,WORKE,'-','LineWidth',LT1out,'Color',[0.4 0.4 0.4]);
axis auto;
%axis ([0 (max(uE)*1.10) 0 (max(WORKE)*1.10)]);
%axis ([0  max(max(u),max(uE))*1.10  0   max(max(WORK),max(WORKE))*1.1]);
xlabel('Energy Displacement [m]','FontSize',ASout, 'FontName',FONTout)
ylabel ('Total Energy [kNm]','FontSize',ASout, 'FontName',FONTout)
title ([handles.NomePush,' Energy Pushover Curves'],'FontSize',TSout, 'FontName',FONTout);
grid;
legend(' Elastic',' Elasto-Plastic ','FontSize',ASout,'FontName',FONTout','Location','NorthWest');
saveas (figu,'Output\Fig.1.3_Energy_curves.tif');
close(figu);

fprintf (filereso,'%s \r\n',' ');

WB = waitbar(19/77);
close(WB);