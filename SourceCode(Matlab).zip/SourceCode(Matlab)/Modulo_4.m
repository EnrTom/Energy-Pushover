%Metodo_4

WB = waitbar(27/77,'Computing EC8-N2 Method');
%METODO ORDINANZA N2 Eurocodice8

fprintf (filereso,'%s \r\n','Computing EC8-N2 Method');
%Trattamento e trasformazione della curva di pushover
baseshear = shear(1:nstep,1);
%Formula per il passaggio del sistema di riferimento
topdispl = displacement(1:nstep,nfloor) - displacement(1,nfloor);
Fx = shear(1:nstep,1)./gamma;
Dx = (topdispl)./gamma;
WB = waitbar(28/77);


%Stampa la curva di capacit�
fprintf (filereso,'%s \r\n','Saving Fig.3.1_Capacity_curve_EC8');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
plot (topdispl,baseshear,'-','LineWidth',LT1out,'Color','k');
hold on;
plot (Dx,Fx,'-','LineWidth',LT1out,'Color','r');
axis auto;
%axis ([0 (max(topdispl))*1.1 0 (max(baseshear))*1.1]);
title('Pushover and Capacity Curves','FontSize',TSout, 'FontName',FONTout);
xlabel ('Xtop, d* [m]','FontSize',ASout, 'FontName',FONTout)
ylabel ('Fb, F* [kN] ','FontSize',ASout, 'FontName',FONTout)
grid;
legend (' Pushover Curve',' Capacity Curve','FontSize',ASout, 'FontName',FONTout,0);
saveas (figu,'Output\Fig.3.1_Capacity_curve_EC8.tif');
%Chiude la figura
close(figu);
WB = waitbar(29/77);

%Determinazione della legge degli spettri e calcolo della soluzione
fprintf (filereso,'%s \r\n','Computing Solution');
%size(Sd);
%nspec=ans(1,1);
%polSd = polyfit(period,Sd(:,1),nspec-1);
%Apre la SubWaitBar
SWB = waitbar(0,'EC8-N2 Method: Processing Status');
SWB = waitbar(1/nstep(1,1));
area(1,1) = 0;
Dxy(1,1) = 0;
kx(1,1) = 0;
duct(1,1) = 1;
Sdx(1,1) = 1;
Sax(1,1) =0;
diff = 1000;
for i=2:nstep
    SWB = waitbar(i/nstep(1,1));
    area(i,1) = area(i-1,1)+(((Fx(i,1)+Fx(i-1,1))./2).*(Dx(i,1)-Dx(i-1,1)));
    Dxy(i,1) = 2.*(Dx(i,1)-(area(i,1)./Fx(i,1)));
    kx(i,1) =  Fx(i,1)./Dxy(i,1);
    Tx(i,1) = 2*pi*sqrt(masstotrid./kx(i,1));
    duct(i,1) = Dx(i,1)./Dxy(i,1);
           
    if Tx(i,1)>=Tc
        Sdx(i,1) = interp1(period,Sd(:,1),Tx(i,1));
    else
        Sax(i,1) = interp1(period,Sa(:,1),Tx(i,1));
        qx(i,1) = Sax(i,1)*masstotrid/Fx(i,1);
        Sdex(i,1) = interp1(period,Sd(:,1),Tx(i,1));
        Sdx(i,1) = Sdex(i,1)/qx(i,1)*(1+(qx(i,1)-1)*(Tc/Tx(i,1)));
        if Sdx(i,1) <= Sdex(i,1)
            Sdx(i,1) = Sdex(i,1);
        end  
    end    
    diff(i,1) = abs((Sdx(i,1)-Dx(i,1))/Dx(i,1)*100);    
end
nsoluz = find(diff==min(diff));
close(SWB); %Chiude la SubWaitBar
WB = waitbar(30/77);

%Graficizzazione della soluzione
fprintf (filereso,'%s \r\n','Saving Fig.3.2_EC8-N2_Method');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Plotta lo spetto elastico
plot (Sd(:,1),Sa(:,1),'-','LineWidth',LT1out,'Color',Colore(1,:));
hold on;
%Plotta la curva capacitiva
plot (Dx,(Fx./masstotrid),'-','LineWidth',LT1out,'Color',Colore(10,:)); %La stampa in rosso
%Plotta la bilineare equivalente
plot ([0,Dxy(nsoluz,1),Dx(nsoluz,1)],[0,(Fx(nsoluz,1))./masstotrid,(Fx(nsoluz,1))./masstotrid],...
    '-','LineWidth',LT1out,'Color',Colore(11,:));  %La stampa in arancione
%Plotta le curve asuliriari per trovare la soluzione
if Tx(nsoluz,1)>=Tc
    plot ([Dxy(nsoluz,1),Dx(nsoluz,1)],[(Fx(nsoluz,1))./masstotrid,(kx(nsoluz,1).*Dx(nsoluz,1))/masstotrid],'--','LineWidth',LT1out*0.3,'Color','k');
    %Servono per stampare solo le soluzioni
    xxx = Dx(nsoluz,1);
    yyy = (kx(nsoluz,1).*Dx(nsoluz,1))/masstotrid;
else
    plot ([Dxy(nsoluz,1),Sdex(nsoluz,1)],[(Fx(nsoluz,1))./masstotrid,Sax(nsoluz,1)],'--','LineWidth',LT1out*0.3,'Color','k');
    xxx = Sdex(nsoluz,1);
    yyy = Sax(nsoluz,1);
end
%Plotta il punto notevole sullo spettro elastico
plot (xxx,yyy,'s','LineWidth',LT1out*0.4,'MarkerEdgeColor','k','MarkerFaceColor',Colore(1,:),'MarkerSize',LT1out*4);
%Plotta il punto notevole sulla curva
plot (Dx(nsoluz,1),(Fx(nsoluz,1))./masstotrid,...
    's','LineWidth',LT1out*0.4,'Color','k','MarkerEdgeColor','k','MarkerFaceColor',Colore(11,:),'MarkerSize',LT1out*4);
axis auto;
%axis ([0 (max(Sd(:,1)))*1.1 0 (max(Sa(:,1)))*1.1]);
title('EC8-N2 Method','FontSize',TSout, 'FontName',FONTout);
xlabel ('Sd, d* [m]','FontSize',ASout, 'FontName',FONTout);
ylabel ('Sa, F* [m/s^2] ','FontSize',ASout, 'FontName',FONTout);
grid;
legend (' Elastic Spectra',' Capacity Curve',' Bilinear Capacity Curve',' Elastic Capacity Curve','Elastic Solution','EC8-N2 Solution','NorthEast');
saveas (figu,'Output\Fig.3.2_EC8-N2_Method.tif');
close(figu);
WB = waitbar(31/77);

%Salvataggio delle coordinate della soluzione del metodo Ordinanza
%Formato soluzione = [nome metodo/passo / max spost / duttilit� / periodo / differenza / lavoro totale]
fprintf (filereso,'%s \r\n','Saving Solution Method EC8-N2');
solution(1,:) = [nsoluz,Dx(nsoluz,1),duct(nsoluz,1),Tx(nsoluz,1),0,area(nsoluz,1)];

%Salvataggio su file della soluzione al problema
filewrite = fopen ('Output\Solutions.doc','w');
fprintf (filewrite,'%s\r\n','NUMERIC SOLUTIONS FOR ALL NON LINEAR STATIC ANALISYS METHODS');
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' ');

fprintf (filewrite,'%s\r\n','SOLUTION OF EUROCODE8-N2 METHOD');

fprintf (filewrite,'%s\r\n','------------------------------------');
fprintf (filewrite,'Solution Step Number [-]   = ');
fprintf (filewrite,'%7i \r\n',nsoluz);

fprintf (filewrite,'Target Displacement d* [m] = '); 
fprintf (filewrite,'%7.5f \r\n',Dx(nsoluz,1)); 

fprintf (filewrite,'Yield Displacement dy* [m] = '); 
fprintf (filewrite,'%7.5f \r\n',Dxy(nsoluz,1));

qq = yyy./((Fx(nsoluz,1))./masstotrid);
fprintf (filewrite,'Reduction Factor q* [-]    =');
fprintf (filewrite,'%8.4f\r\n',qq);

fprintf (filewrite,'Ductility [-]              = ');
fprintf (filewrite,'%7.4f\r\n',duct(nsoluz,1));

fprintf (filewrite,'Stiffness k* [kN/m]        = ');
fprintf (filewrite,'%7.1f\r\n',kx(nsoluz,1));

fprintf (filewrite,'Period T* [sec]            = ');
fprintf (filewrite,'%7.4f\r\n',Tx(nsoluz,1));

fprintf (filewrite,'Base Shear [kN]            = ');
fprintf (filewrite,'%7.2f\r\n',shear(nsoluz,1));

fprintf (filewrite,'Max Top Displacement [m]   = ');
fprintf (filewrite,'%7.5f\r\n',displacement(nsoluz,nfloor)); 

fprintf (filewrite,'Total Work [kNm]           = ');
fprintf (filewrite,'%7.4f\r\n',area(nsoluz,1));

fprintf (filewrite,'Total Mass [t]             = ');
fprintf (filewrite,'%7.2f\r\n',masstot);

fprintf (filewrite,'Total Mass* First Mode [t] = ');
fprintf (filewrite,'%7.2f\r\n',masstotrid);

fprintf (filewrite,'Percentage M*/Mtot [p]     = ');
fprintf (filewrite,'%7.2f\r\n',masstotrid/masstot*100);

fprintf (filewrite,'Partecip. Ratio Gamma [-]  =');
fprintf (filewrite,'%8.4f\r\n',gamma);
fprintf (filewrite,'%s\r\n',' ');
fprintf (filewrite,'%s\r\n',' ');
fclose(filewrite);

fprintf (filereso,'%s \r\n',' ');

WB = waitbar(32/77);
close(WB);