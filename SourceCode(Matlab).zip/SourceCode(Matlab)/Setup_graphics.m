%File con le impostazioni per la stampa dei grafici in oputput nel file
FONTout = 'Times New Roman';  %Font per tutti i grafici
LT1out = 3;  %Spessore linea primaria


%Titolo
TSout = 28;  %Altezza del carattare del titolo

%Assi
ASout  = 20;  %Altezza del carattare dell'asse
ANSout = 16;  %Altezza del carattare dell'asse graduazione

WB = waitbar(1/77,'Setup Graphics');
close(WB);