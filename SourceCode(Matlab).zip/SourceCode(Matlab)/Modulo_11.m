%Modulo_11
%Riporta a video gli errori globali calcolati per i vari metodi
WB = waitbar(73/77,'Showing Result');

%Errori degli spostamenti
fprintf (filereso,'%s\r\n','Showing Total Displacement Error Values');
set(handles.editSN,'String',num2str(chop(epsilondisp(1),3)));
set(handles.editSA,'String',num2str(chop(epsilondisp(2),3)));
set(handles.editSB,'String',num2str(chop(epsilondisp(3),3)));
WB = waitbar(74/77);

%Errori degli scorrimenti
fprintf (filereso,'%s\r\n','Showing Total Drift Error Values');
set(handles.editDN,'String',num2str(chop(epsilondrift(1),3)));
set(handles.editDA,'String',num2str(chop(epsilondrift(2),3)));
set(handles.editDB,'String',num2str(chop(epsilondrift(3),3)));
WB = waitbar(75/77);

%Errori del taglio alla base
fprintf (filereso,'%s\r\n','Showing Base Shear Error Values');
set(handles.editVN,'String',num2str(chop(errorshear(1),3)));
set(handles.editVA,'String',num2str(chop(errorshear(2),3)));
set(handles.editVB,'String',num2str(chop(errorshear(3),3)));

fprintf (filereso,'%s\r\n',' ');
WB = waitbar(76/77);

