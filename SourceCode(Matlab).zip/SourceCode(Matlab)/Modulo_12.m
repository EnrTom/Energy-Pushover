%Modulo_12
%� un modulo aggiuntivo che serve per altre cose

%PARTE DI COMODO CHE SERVE PER ALTRI SCOPO RISPETTO A QUELLI DEL PROGRAMMA
filewrite = fopen ('Output\Curve_A.txt','w');
fprintf (filewrite,'%s \n\r',' ');
fprintf (filewrite,'%s \n\r','Curva Pushover - Metodo A:');
fprintf (filewrite,'%s \n\r','----------------------------------');
fprintf (filewrite,'%s \n\r','      u          w        duct.');
fprintf (filewrite,'%s \n\r','     (m)     (m^2/s^2)     (-)');
fprintf (filewrite,'%s \n\r','----------------------------------');
%Riporta sul file la curva nello spazio EDmRS
for i=1:nstep
    fprintf (filewrite,'%10.6f %10.6f %10.6f \r\n',u(i),eM(i),duttM(i));
end
fclose(filewrite);



%PARTE DI COMODO CHE SERVE PER ALTRI SCOPO RISPETTO A QUELLI DEL PROGRAMMA
filewrite = fopen ('Output\Curve_B.txt','w');
fprintf (filewrite,'%s \n\r',' ');
fprintf (filewrite,'%s \n\r','Curva Pushover - Metodo B:');
fprintf (filewrite,'%s \n\r','Curva Pushover Elastica:');
fprintf (filewrite,'%s \n\r','----------------------------------');
fprintf (filewrite,'%s \n\r','      u          w        duct.');
fprintf (filewrite,'%s \n\r','     (m)     (m^2/s^2)     (-)');
fprintf (filewrite,'%s \n\r','----------------------------------');
%Riporta sul file la curva nello spazio EDmRS con duttilit� = 1 (caso elastico)
for i=1:nstepE
    fprintf (filewrite,'%10.6f %10.6f %10.6f \r\n',uE(i),eE(i),1);
end
fclose(filewrite);

filewrite = fopen ('Output\Curve_T-cost.txt','w');
fprintf (filewrite,'%s \n\r','Curva Spettro a T cost: D(Tcost) - PsE( T cost) - dutt ');
fprintf (filewrite,'%s \n\r','----------------------------------');
fprintf (filewrite,'%s \n\r','      D         PsE       duct.');
fprintf (filewrite,'%s \n\r','     (m)     (m^2/s^2)     (-)');
fprintf (filewrite,'%s \n\r','----------------------------------');
for i=1:ndutt
    fprintf (filewrite,'%10.6f %10.6f %10.6f \n\r',xTcost(i,1),yTcost(i,1),duttility(i));
end
fclose(filewrite);
