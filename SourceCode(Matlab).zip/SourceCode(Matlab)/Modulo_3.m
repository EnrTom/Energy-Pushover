%Modulo_3

WB = waitbar(19/77,'Reading Spectra');
%Inizio della lettura degli spettri

%legge le info dello spettro come numero di duttilit� e Tc*
fprintf (filereso,'%s \r\n','Reading Spectra Info');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Spettri\Info_spectra.txt'],'r');
ndutt = fscanf (fileread,'%g',[1,1]);
duttility = fscanf (fileread,'%g',[ndutt,1]);
duttility = duttility';
Tc = fscanf (fileread,'%g',[1,1]);
fclose(fileread);
WB = waitbar(20/77);

%Legge il file degli spostamenti spettrali
fprintf (filereso,'%s \r\n','Reading Displacement Spectra');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Spettri\',handles.CartellaSpectra,'\spec_disp.txt']','r');
Sd = fscanf(fileread,'%g',[(ndutt+1),inf]);
fclose (fileread);
Sd = Sd';
period = Sd(2:end,1);
Sd(1,:) = [ ];
Sd(:,1) = [ ];
WB = waitbar(21/77);

%Stampa sul file output lo spettro di spostamento
fprintf (filereso,'%s \r\n','Saving Fig.2.1_Displacement_spectra');
%Non fa vedere la figura
figu = figure ('Visible','off');
%Imposta gli assi del grafico
axes('FontSize',ANSout,'FontName',FONTout);
hold on;
for i = 1:ndutt
    plot(period(:,1),Sd(:,i),'-','LineWidth',LT1out,'Color',Colore(i,:));
end
axis auto;
%axis ([0 (max(max(period))*1.1) 0 (max(max(Sd))*1.10)]);
xlabel ('Period [s] ','FontSize',ASout, 'FontName',FONTout);
ylabel ('Displacement [m]','FontSize',ASout, 'FontName',FONTout)
title ('Displacement Spectra','FontSize',TSout, 'FontName',FONTout);
grid;
%Salva il file nella cartella di output
saveas (figu,'Output\Fig.2.1_Displacement_spectra.tif');
%Chiude la figura
close(figu);
WB = waitbar(22/77);


%Legge il file delle pseudo-accelerazioni spettrali
fprintf (filereso,'%s \r\n','Reading Pseudo-Acceleration Spectra');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Spettri\',handles.CartellaSpectra,'\spec_acc.txt']','r');
Sa = fscanf(fileread,'%g',[(ndutt+1),inf]);
fclose (fileread);
Sa = Sa';
Sa(1,:) = [ ];
Sa(:,1) = [ ];
WB = waitbar(23/77);

%Stampa sul file output lo spettro di pseudo-accelerazione
fprintf (filereso,'%s \r\n','Saving Fig.2.2_Ps-acceleration_Spectra');
%Non fa vedere la figura
figu = figure ('Visible','off');
%Imposta gli assi del grafico
axes('FontSize',ANSout,'FontName',FONTout);
hold on;
for i = 1:ndutt
    plot(period(:,1),Sa(:,i),'-','LineWidth',LT1out,'Color',Colore(i,:));
end
axis auto;
%axis ([0 (max(max(period))*1.10) 0 (max(max(Sa))*1.10)]);
xlabel ('Period [s]','FontSize',ASout, 'FontName',FONTout);
ylabel ('Pseudo-Acceleration [m/s^2]','FontSize',ASout, 'FontName',FONTout);
title ('Pseudo-Acceleration Spectra','FontSize',TSout, 'FontName',FONTout);
grid;
%Salva il file nella cartella di output
saveas (figu,'Output\Fig.2.2_Ps-acceleration_Spectra.tif');
%Chiude la figura
close(figu);
WB = waitbar(24/77);


%Legge il file delle pseudo-energia spettrali
fprintf (filereso,'%s \r\n','Reading Pseudo-Energy Spectra');
fileread = fopen (['Database\Modello ',handles.NomeModello,'\Spettri\',handles.CartellaSpectra,'\spec_ener.txt']','r');
Se = fscanf(fileread,'%g',[(ndutt+1),inf]);
fclose (fileread);

Se = Se';
Se(1,:) = [ ];
Se(:,1) = [ ];
WB = waitbar(25/77);

%Stampa sul file output lo spettro di pseudo-energia
fprintf (filereso,'%s \r\n','Saving Fig.2.3_Ps-energy_Spectra');
%Non fa vedere la figura
figu = figure ('Visible','off');
%Imposta gli assi del grafico
axes('FontSize',ANSout,'FontName',FONTout);
hold on;
for i = 1:ndutt
    plot(period(:,1),Se(:,i),'-','LineWidth',LT1out,'Color',Colore(i,:));
end
axis auto;
%axis ([0 (max(max(period))*1.10) 0 (max(max(Se))*1.10)]);
xlabel ('Period [s]','FontSize',ASout, 'FontName',FONTout);
ylabel ('Pseudo-Energy [m^2/s^2]','FontSize',ASout, 'FontName',FONTout);
title ('Pseudo-Energy Spectra ','FontSize',TSout, 'FontName',FONTout);
grid;
saveas (figu,'Output\Fig.2.3_Ps-energy_Spectra.tif');
%Chiude la figura
close(figu);
WB = waitbar(26/77);



%Stampa sul file output lo spettro di pseudo-energia vs. spostamento
fprintf (filereso,'%s \r\n','Saving Fig.2.4_Ps-energy_vs_Displacement_Spectra');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
hold on;
for i = 1:ndutt
    plot(Sd(:,i),Se(:,i),'-','LineWidth',LT1out,'Color',Colore(i,:));
end
axis auto;
%axis ([0 (max(max(Sd))*1.10) 0 (max(max(Se))*1.10)]);
xlabel ('Displacement [m] ','FontSize',ASout, 'FontName',FONTout);
ylabel ('Pseudo-Energy [m^2/s^2]','FontSize',ASout, 'FontName',FONTout);
title ('Pseudo-Energy vs. Displacement Spectra','FontSize',TSout, 'FontName',FONTout);
grid;
saveas (figu,'Output\Fig.2.4_Ps-energy_vs_Displacement_Spectra.tif');
close (figu);

nspec = max(size(Sd));
size(period);
matdutt = [];

%figure ('Visible','off');
%axes('FontSize',ANSout,'FontName',FONTout);
%hold on;
%for i=1:max(size(period));
%    matdutt = [matdutt;duttility];
%end
%surf (matdutt,Sd,Se);
%axis auto;
%axis ([0 (max(max(matdutt))*1.10) 0 (max(max(Sd))*1.10) 0 (max(max(Se))*1.10)]);
%xlabel ('Duttility','FontSize',ASout, 'FontName',FONTout);
%ylabel ('Displacement [m] ','FontSize',ASout, 'FontName',FONTout);
%zlabel ('Pseudo-Energy [m^2/s^2]','FontSize',ASout, 'FontName',FONTout);
%title ('Ps-Energy vs. Displacement vs. Ductility Spectra','FontSize',TSout, 'FontName',FONTout);
%text(0,0,0,'[click with mouse to rotate the figure]');
%rotate;
%pause;
%print -dbmp16m Output\Fig.2.5_3D_Spectra.tif;
%close (figure);

%Stampa sul file output lo spettro di pseudo-energia vs. spostamento
fprintf (filereso,'%s \r\n',' ');

WB = waitbar(27/77);
close(WB);