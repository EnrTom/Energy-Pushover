%Modulo_10
%Stampa dei grafici a video
WB = waitbar(68/77,'Showing Graphics');

fprintf (filereso,'%s\r\n','Showing Solution on Pushover Curve');
%Visualizzazione sulla curva di pushover delle soluzioni dei vari metodi
%Seleziona il grafico dove va la stampa
axes(handles.axesPush);
%Stampa i grafici richiesti
%Plotta la soluzione del metodo EC8-N2
%Plotta la curva di pushover su cui riportare le soluzioni
plot (displacement(:,nfloor),shear(:,1),'-','LineWidth',LT1*1.4,'Color','k');
hold on;
plot (dispOrd(nfloor,1),shearOrd(1,1),'s','LineWidth',LT1*0.4,'MarkerEdgeColor','k','MarkerFaceColor',ColoreN2,'MarkerSize',LT1*4);
hold on;
%Plotta la soluzione del metodo energetico "A"
plot (dispMez(nfloor,1),shearMez(1,1),'s','LineWidth',LT1*0.4,'MarkerEdgeColor','k','MarkerFaceColor',ColoreEA,'MarkerSize',LT1*4);
hold on
%Plotta la soluzione del metodo energetico "B"
plot (dispTom(nfloor,1),shearTom(1,1),'s','LineWidth',LT1*0.4,'MarkerEdgeColor','k','MarkerFaceColor',ColoreEB,'MarkerSize',LT1*4);
hold on;
%Plotta il rettangolo (o ellisse) dell'intervallo delle soluzioni
rectangle ('Curvature',[1 1],'Position',[dispTime(nfloor,4),shearTime(2,4),2*dispTime(nfloor,2),2*shearTime(2,2)],...
    'LineWidth',LT1*0.4,'LineStyle','-','FaceColor',[0.9 0.9 0.9]);  
%Plotta la soluzione della time history
plot (dispTime(nfloor,1),shearTime(2,1),'s','LineWidth',LT1*0.4,'MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1*4);
hold on;
grid;
%Imposta i limiti degli assi del grafico
%axis ([0 (MaxX*1.10) 0 (MaxY*1.10)]);
%Imposta le caratteristiche degli assi
set(handles.axesPush,'FontSize',ANS,'FontName',FONT);
%Da il nome all'asse delle X e delle Y
xlabel('Top Dispacement [m]','FontSize',AS, 'FontName',FONT);
ylabel('Base Shear [kN]','FontSize',AS, 'FontName',FONT);
%Da il nome al titolo del grafico
title ([handles.NomePush,' Pushover Curve'],'FontSize',TS, 'FontName',FONT);
%Mette la griglia;
grid;
WB = waitbar(69/77);

%Mostra l'errore percentuale degli spostamenti
fprintf (filereso,'%s\r\n','Showing Storey Drift Error');
axes(handles.axesPdisp);  %Selezioan grafico
%Stampa i grafici richiesti
bar (floor(2:nfloor+1),errordisp,1); %Mette gli istogrammi
colormap ([ColoreN2;ColoreEA;ColoreEB]); %Lo colora con i rispettivi colori
set(handles.axesPdisp,'FontSize',ANS,'FontName',FONT);  %Assi
xlabel('Storey','FontSize',AS, 'FontName',FONT);   %Nome assi
ylabel('Error [%]','FontSize',AS, 'FontName',FONT);  %Nome assi
title ('Displacement','FontSize',TS, 'FontName',FONT);  %Titolo grafico
grid;


%Mostra l'errore percentuale degli scorrimenti
axes(handles.axesPdrift);  %Selezioan grafico
fprintf (filereso,'%s\r\n','Showing Storey Displacement Error');
%Stampa i grafici richiesti
bar (floor(2:nfloor+1),errordrift,1); %Mette gli istogrammi
colormap ([ColoreN2;ColoreEA;ColoreEB]); %Lo colora con i rispettivi colori
set(handles.axesPdrift,'FontSize',ANS,'FontName',FONT);  %Assi
xlabel('Storey','FontSize',AS, 'FontName',FONT);   %Nome assi
ylabel('Error [%]','FontSize',AS, 'FontName',FONT);  %Nome assi
title ('Drift','FontSize',TS, 'FontName',FONT);  %Titolo grafico
grid;
WB = waitbar(70/77);

%Mostra l'errore percentuale del taglio alla base
fprintf (filereso,'%s\r\n','Showing Base Shear Error');
axes(handles.axesPshear);  %Selezioan grafico
%Stampa i grafici richiesti
bar ([1 2],[errorshear;0 0 0],1); %Mette gli istogrammi
colormap ([ColoreN2;ColoreEA;ColoreEB]); %Lo colora con i rispettivi colori
set(handles.axesPshear,'FontSize',ANS,'FontName',FONT);  %Assi
xlabel('Case','FontSize',AS, 'FontName',FONT);   %Nome assi
ylabel('Error [%]','FontSize',AS, 'FontName',FONT);  %Nome assi
title ('Base Shear','FontSize',TS, 'FontName',FONT);  %Titolo grafico
%xlim([0.6 1.4]);
grid;
WB = waitbar(71/77);

%Mostra la deformata degli spostamenti
fprintf (filereso,'%s\r\n','Showing Dispacement Shape');
axes(handles.axesDisp);  %Selezioan grafico
%Serve per colorare in grigetto la "zona" della soluzione
%Tali vettori servono solo per il comando pacth
paX = [0;dispTime(:,5)];
paY = floor';
for i = 1:nfloor
    paX = [paX;dispTime(nfloor+1-i,4)];
    paY = [paY;floor(nfloor+2-i)];
end
patch (paX,paY,[0.9 0.9 0.9],'EdgeColor','w');
hold on;
%Stampa i grafici richiesti
%Plotta la deformata della time history media
plot ([0;dispTime(:,1)],floor,'-','LineWidth',LT1,'Color','k');
hold on;
%Plotta la defomata della time history media meno la dev. stand.
plot ([0;dispTime(:,4)],floor,'--','LineWidth',LT1*0.7,'Color','k');
%Plotta la defomata della time history media pi� la dev. stand.
plot ([0;dispTime(:,5)],floor,'--','LineWidth',LT1*0.7,'Color','k');
axis auto;
%Plotta la defomrata ottenunta dal metofo EC8-N2
plot ([0;dispOrd],floor,'-','LineWidth',LT1,'Color',ColoreN2);    
%Plotta la defomrata ottenunta dal metofo energetico A
plot ([0;dispMez],floor,'-','LineWidth',LT1,'Color',ColoreEA);    
%Plotta la defomrata ottenunta dal metodo B
plot ([0;dispTom],floor,'-','LineWidth',LT1,'Color',ColoreEB);
%plotta il punti di demarcazione
for i = 1:nfloor
    plot(dispTime(i,1),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1*2);
    plot(dispOrd(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreN2,'MarkerSize',LT1*2);
    plot(dispMez(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEA,'MarkerSize',LT1*2);
    plot(dispTom(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEB,'MarkerSize',LT1*2);
end
xlabel ('Displacement [m]','FontSize',AS, 'FontName',FONT);
ylabel ('Storey','FontSize',AS, 'FontName',FONT);
title ('Displacement','FontSize',TS, 'FontName',FONT);
grid;
WB = waitbar(72/77);

%Mostra la deformata degli scorrimenti
fprintf (filereso,'%s\r\n','Showing Drift Shape');
axes(handles.axesDrift);  %Selezioan grafico
%Serve per colorare in grigetto la "zona" della soluzione
%Tali vettori servono solo per il comando pacth
paX = [0;drifTime(:,5)];
paY = floor';
for i = 1:nfloor
    paX = [paX;drifTime(nfloor+1-i,4)];
    paY = [paY;floor(nfloor+2-i)];
end
patch (paX,paY,[0.9 0.9 0.9],'EdgeColor','w');
hold on;
%Stampa i grafici richiesti
%Plotta la deformata della time history media
plot ([0;drifTime(:,1)],floor,'-','LineWidth',LT1,'Color','k');
hold on;
%Plotta la defomata della time history media meno la dev. stand.
plot ([0;drifTime(:,4)],floor,'--','LineWidth',LT1*0.7,'Color','k');
%Plotta la defomata della time history media pi� la dev. stand.
plot ([0;drifTime(:,5)],floor,'--','LineWidth',LT1*0.7,'Color','k');
axis auto;
%Plotta la defomrata ottenunta dal metofo EC8-N2
plot ([0;drifOrd],floor,'-','LineWidth',LT1,'Color',ColoreN2);    
%Plotta la defomrata ottenunta dal metofo energetico A
plot ([0;drifMez],floor,'-','LineWidth',LT1,'Color',ColoreEA);    
%Plotta la defomrata ottenunta dal metodo B
plot ([0;drifTom],floor,'-','LineWidth',LT1,'Color',ColoreEB);
%plotta il punti di demarcazione
for i = 1:nfloor
    plot(drifTime(i,1),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1*2);
    plot(drifOrd(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreN2,'MarkerSize',LT1*2);
    plot(drifMez(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEA,'MarkerSize',LT1*2);
    plot(drifTom(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEB,'MarkerSize',LT1*2);
end
xlabel ('Drift [m]','FontSize',AS, 'FontName',FONT);
ylabel ('Storey','FontSize',AS, 'FontName',FONT);
title ('Drift','FontSize',TS, 'FontName',FONT);
grid;

fprintf (filereso,'%s\r\n',' ');

WB = waitbar(73/77);
close(WB);
