%Modulo_8
%Calcolo e plottaggio dei risutati comparati con la time history
WB = waitbar(55/77,'Saving Output Graphics');

%Visualizzo i dati ottenuti (SPOSTAMENTI)
fprintf (filereso,'%s \r\n','Saving Fig.6.2_Cfr_disp_def');
floor = 0:1:nfloor;
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);

%Serve per colorare in grigetto la "zona" della soluzione
%Tali vettori servono solo per il comando pacth
paX = [0;dispTime(:,5)];
paY = floor';
for i = 1:nfloor
    paX = [paX;dispTime(nfloor+1-i,4)];
    paY = [paY;floor(nfloor+2-i)];
end
patch (paX,paY,[0.9 0.9 0.9],'EdgeColor','w');
hold on;

%Plotta la deformata della time history media
plot ([0;dispTime(:,1)],floor,'-','LineWidth',LT1out,'Color','k');
hold on;
%Plotta la defomata della time history media meno la dev. stand.
plot ([0;dispTime(:,4)],floor,'--','LineWidth',LT1out*0.7,'Color','k');
%Plotta la defomata della time history media pi� la dev. stand.
plot ([0;dispTime(:,5)],floor,'--','LineWidth',LT1out*0.7,'Color','k');
axis auto;
%Plotta la defomrata ottenunta dal metofo EC8-N2
plot ([0;dispOrd],floor,'-','LineWidth',LT1out,'Color',ColoreN2);    
%Plotta la defomrata ottenunta dal metofo energetico A
plot ([0;dispMez],floor,'-','LineWidth',LT1out,'Color',ColoreEA);    
%Plotta la defomrata ottenunta dal metodo B
plot ([0;dispTom],floor,'-','LineWidth',LT1out,'Color',ColoreEB);
%plotta il punti di demarcazione
for i = 1:nfloor
    plot(dispTime(i,1),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4);
    plot(dispOrd(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreN2,'MarkerSize',LT1out*4);
    plot(dispMez(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEA,'MarkerSize',LT1out*4);
    plot(dispTom(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEB,'MarkerSize',LT1out*4);
end
grid;
xlabel ('Floor Displacement [m]','FontSize',ASout, 'FontName',FONTout);
ylabel ('Floor','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Storey Displacement','FontSize',TSout, 'FontName',FONTout);
legend ('Solution Range','Mean time history','Mean time history - \sigma','Mean time history + \sigma',...
    'EC8-N2 Method','Energy "A" Method','Energy "B" Method',0);
saveas (figu,'Output\Fig.6.2_Cfr_disp_def.tif');
close(figu);
WB = waitbar(56/77);


%Visualizzo gli errori percentuale (SPOSTAMENTI)
fprintf (filereso,'%s \r\n','Saving Fig.6.3_Cfr_disp_perc');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Plotta gli istogrammi degli errori
bar (floor(2:nfloor+1),errordisp,1);
%Non so bene a cosa serve, mi sa che sono i colori ?!?!?!?!?!?
colormap ([ColoreN2;ColoreEA;ColoreEB]);
legend ('EC8-N2 Method','Energy "A" Method','Energy "B" Method',0);
grid;
xlabel ('Storey','FontSize',ASout, 'FontName',FONTout);
ylabel ('Storey Displacement Error [%]','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Storey Displacement Error','FontSize',TSout, 'FontName',FONTout);
saveas (figu,'Output\Fig.6.3_Cfr_disp_perc.tif');
close(figu);
WB = waitbar(57/77);



%Visualizzo i dati ottenuti (SCORRIMENTI)
fprintf (filereso,'%s \r\n','Saving Fig.6.4_Cfr_drift_def');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Serve per colorare in grigetto la "zona" della soluzione
%Tali vettori servono solo per il comando pacth
paX = [0;drifTime(:,5)];
for i = 1:nfloor
    paX = [paX;drifTime(nfloor+1-i,4)];
end
patch (paX,paY,[0.9 0.9 0.9],'EdgeColor','w');
hold on;
%plotta i drift di piano della time history media, m+dev., m-dev. 
plot ([0;drifTime(:,1)],floor,'-','LineWidth',LT1out,'Color','k');
hold on;
plot ([0;drifTime(:,4)],floor,'--','LineWidth',LT1out*0.7,'Color','k');
plot ([0;drifTime(:,5)],floor,'--','LineWidth',LT1out*0.7,'Color','k');
%Plotta le deformate per i 3 metodi: N2, A e B
plot ([0;drifOrd],floor,'-','LineWidth',LT1out,'Color',ColoreN2);
plot ([0;drifMez],floor,'-','LineWidth',LT1out,'Color',ColoreEA);
plot ([0;drifTom],floor,'-','LineWidth',LT1out,'Color',ColoreEB);
%Plotta i rispettivi marcatori
for i = 1:nfloor
    plot(drifTime(i,1),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',[0.4 0.4 0.4],'MarkerSize',LT1out*4);
    plot(drifOrd(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreN2,'MarkerSize',LT1out*4);
    plot(drifMez(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEA,'MarkerSize',LT1out*4);
    plot(drifTom(i),i,'Marker','o','MarkerEdgeColor','k','MarkerFaceColor',ColoreEB,'MarkerSize',LT1out*4);
end
grid;
xlabel ('Storey Drift [m]','FontSize',ASout, 'FontName',FONTout);
ylabel ('Storey','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Storey Drift Error','FontSize',TSout, 'FontName',FONTout);
legend ('Solution Range','Mean time history','Mean time history - \sigma','Mean time history + \sigma',...
    'EC8-N2 Method','Energy "A" Method','Energy "A" Method',0);
saveas (figu,'Output\Fig.6.4_Cfr_drift_def.tif');
close(figu);
WB = waitbar(58/77);


%Visualizzo gli errori percentuale (SCORRIMENTI)
fprintf (filereso,'%s \r\n','Saving Fig.6.5_Cfr_disp_perc');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
bar (floor(2:nfloor+1),errordrift,1);
colormap ([ColoreN2;ColoreEA;ColoreEB]);
legend ('EC8-N2 Method','Energy "A" Method','Energy "B" Method',0);
grid;
xlabel ('Storey','FontSize',ASout, 'FontName',FONTout);
ylabel ('Storey Drift Error [%]','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Storey Drift Error ','FontSize',TSout, 'FontName',FONTout);
saveas (figu,'Output\Fig.6.5_Cfr_disp_perc.tif');
close(figu);
WB = waitbar(59/77);


%Visualizzo i dati ottenuti (TAGLI)
fprintf (filereso,'%s \r\n','Saving Fig.6.6_Cfr_Shear');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Per traccaire il grafico ci metto un gruppo in piu di tutti uno che poi nascondo
bar ([1 2],[shearOrd(1,1),shearMez(1,1),shearTom(1,1);1 1 1],1);
colormap ([ColoreN2;ColoreEA;ColoreEB]);
hold on;
plot ([0.6 1.4],[shearTime(2,1),shearTime(2,1)],'-','LineWidth',LT1out,'Color','k');  %Tira una linea per il valore medio
hold on;
plot ([0.6 1.4],[shearTime(2,4),shearTime(2,4)],'--','LineWidth',LT1out*0.7,'Color','k');  %Tira una linea per il valore medio - dev.
hold on;
plot ([0.6 1.4],[shearTime(2,5),shearTime(2,5)],'--','LineWidth',LT1out*0.7,'Color','k');  %Tira una linea per il valore medio + dev.
hold on;
grid;
xlabel ('Case','FontSize',ASout, 'FontName',FONTout);
ylabel ('Base Shear [kN]','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Base Shear','FontSize',TSout, 'FontName',FONTout);
xlim = [0.6 1.4];
%legend ('Mean time history','Mean time history - \sigma','Mean time history + \sigma',4);
saveas (figu,'Output\Fig.6.6_Cfr_Shear.tif');
close(figu);
WB = waitbar(60/77);


%Visualizzo gli errori percentuale (TAGLI)
fprintf (filereso,'%s \r\n','Saving Fig.6.7_Cfr_Shear_Perc');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Per traccaire il grafico ci metto un gruppo in piu di tutti uno che poi
%nascondo
bar ([1 2],[errorshear; 1 1 1],1);
colormap ([ColoreN2;ColoreEA;ColoreEB]);
hold on;
legend ('EC8-N2 Method','Energy "A" Method','Energy "B" Method',0);
grid;
ylabel ('Base Shear Error [%]','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Base Shear Error','FontSize',TSout, 'FontName',FONTout);
xlim = [0.6 1.4];
saveas (figu,'Output\Fig.6.7_Cfr_Shear_Perc.tif');
close(figu);
WB = waitbar(61/77);

%Confronto tra i sistemi bilineari equivalenti impiegati nelle analisi
fprintf (filereso,'%s \r\n','Saving Fig.6.8_Cfr_SDOF');
figu = figure ('Visible','off');
axes('FontSize',ANSout,'FontName',FONTout);
%Calcola e plotta lo SDOF per il metodo EC8-N2
bilineOrd(1:3,1) = [0;Dxy(nsoluz,1);Dx(nsoluz,1)];
bilineOrd(1:3,2) = [0;shear(nsoluz,1)/masstot;shear(nsoluz,1)/masstot];
plot (bilineOrd(:,1),bilineOrd(:,2),'-','LineWidth',LT1out*3,'Color',ColoreN2);

%Calcola e plotta lo SDOF per il metodo enrgetico "A"
bilineMez(1:3,1) = [0;usolM/duttsolM;usolM];
bilineMez(1:3,2) = [0;shearsolM/massmez;shearsolM/massmez];
hold on;
plot (bilineMez(:,1),bilineMez(:,2),'-','LineWidth',LT1out*3,'Color',ColoreEA);

%Calcola e plotta lo SDOF per il metodo enrgetico "B"
bilineTom(1:3,1) = [0;usol/duttisol;usol];
bilineTom(1:3,2) = [0;shearsol/masstomas;shearsol/masstomas];
hold on;
plot (bilineTom(:,1),bilineTom(:,2),'-','LineWidth',LT1out*3,'Color',ColoreEB);

grid;
xlabel ('Displacement [m]','FontSize',ASout, 'FontName',FONTout);
ylabel ('Pseudo-Acceleration [m/s^2]','FontSize',ASout, 'FontName',FONTout);
title ('Comparison of Equivalent SDOF Systems','FontSize',TSout, 'FontName',FONTout);
legend ('EC8-N2 Method','Energy "A" Method','Energy "B" Method',4);
saveas (figu,'Output\Fig.6.8_Cfr_SDOF.tif');
close(figu);

fprintf (filereso,'%s \r\n',' ');

WB = waitbar(62/77);
close(WB);